# Lab 12 — Apple full analysis and partner review

Prepared October 1, 2026. Financial amounts are USD millions unless stated otherwise; per-share values are USD. This document organizes existing models and the student's supplied partner notes. It does not claim undocumented classroom exchanges or completed checks.

## Current conclusion

The latest Apple Services model estimates **$125.52 per share**. Under its assumptions, it does not support initiating a purchase at the saved **$335.92 September 24, 2026** reference price. This is a conditional classroom conclusion: the forecast starts at FY2025 and has not been rolled forward to that quote date. It is not a current-price recommendation.

## 1. Target selection

The original Apple research memo selected Apple for its iPhone franchise, growing Services business, liquidity, and capital returns, and initially concluded **buy**. Detailed audited disclosures make Apple suitable for tracing operating assumptions through financial statements to valuation. The original thesis also allowed a change to watch/do not initiate if price exceeded a defensible intrinsic estimate.

The distinction developed through this project is between an attractive business and an attractive purchase price. Services growth can improve business economics without making every market price reasonable.

## 2. Company and evidence

Apple sells iPhone, Mac, iPad, wearables and accessories, and Services including advertising, cloud services, digital content and payment services. History comes from Apple's FY2023–FY2025 10-Ks, for years ended September 30, 2023; September 28, 2024; and September 27, 2025.

| Reported item, USD millions | FY2023 | FY2024 | FY2025 |
|---|---:|---:|---:|
| Revenue | 383,285 | 391,035 | 416,161 |
| Services revenue | 85,200 | 96,169 | 109,158 |

Sources: [FY2023 10-K](https://www.sec.gov/Archives/edgar/data/320193/000032019323000106/aapl-20230930.htm), [FY2024 10-K](https://www.sec.gov/Archives/edgar/data/320193/000032019324000123/aapl-20240928.htm), [FY2025 10-K](https://www.sec.gov/Archives/edgar/data/320193/000032019325000079/aapl-20250927.htm). Full sourced historical grids and financial statements are included in the evidence folder.

FY2025 Services revenue was 109,158 and gross profit 82,314: a 75.41% gross margin. Products revenue was 307,003 and gross profit 112,887: a 36.77% margin. These are reported category economics, not an estimated iPhone margin. A larger Services mix can therefore lift consolidated gross margin even with constant category margins.

The student previously confirmed checking FY2023 revenue of 383,285 and FY2024 net income of 93,736 personally. The saved history report compares filing capital spending with Yahoo Finance after unit conversion. These prior personal checks are distinct from the missing Lab 12 joint partner check.

## 3. Pro-forma

The current model forecasts FY2026–FY2030 from FY2025 balances. Its operating driver is Services growth; Products growth stays fixed.

| Value | Label | Reason |
|---|---|---|
| Products growth 5%; Services growth 10% annually | Judgment | Model moderate product growth and faster Services expansion; these are not management guidance. |
| Products margin 36.77%; Services margin 75.41% | Judgment using history | Hold starting category profitability constant to isolate the revenue-mix effect. |
| SG&A / gross profit 14.1%; R&D / revenue 8.3% | Judgment using history | Let expenses scale with activity while preserving Apple's separate R&D line. |
| Tax rate 16% | Judgment | Use a normalized rate rather than repeat FY2024's exceptional tax burden. |
| Annual capex 12,715 | Judgment using history | Retain FY2025 spending as the baseline; faster Services growth may require more investment. |
| PP&E depreciation / opening PP&E = 8,000 / 49,834; other D&A 3,698 annually | Historical calibration / judgment | Use the saved depreciation schedule; the other-D&A allocation is simplified. |
| Inventory = Products cost of sales × 5,718 / 194,116 | Judgment using history | Tie physical inventory to Products rather than Services sales. |
| Other operating working-capital ratios held at FY2025 levels | Judgment | Preserve the original account relationships; Services-specific ratios remain a research priority. |
| Floor-plan financing: none | Judgment | No ABG-style inventory financing is modeled for Apple; R&D is the named company-specific line. |
| Cost of equity 10%; terminal growth 2.5% | Judgment | Use a transparent equity hurdle rate and mature long-run growth. |

Revenue and category margins determine gross profit; SG&A and R&D determine operating income; taxes determine earnings. D&A, working capital, capex and debt repayments connect earnings to FCFE. Cash follows the cash-flow statement; PP&E follows investment and depreciation; debt and equity roll forward with financing and distributions. D&A already included in operating expenses is not deducted twice.

The model retains annual debt repayments of 10,932, dividends of 15,421, target buybacks of 90,711, and a cash floor of 25,000. Buybacks can fall to protect liquidity. All 25 saved scenario-year balance-sheet checks passed, and no tested case required a buyback reduction. Accounting consistency does not verify economic realism.

## 4. Valuation

| Model | Basis and assumptions | Value/share |
|---|---|---:|
| Latest Services FCFE | FY2025 base; FY2026–FY2030 forecast; cost of equity 10%; terminal growth 2.5%; 14,773.260 million FY2025 year-end shares | **125.52** |
| Earlier Lab 10 FCFE | Same share basis; 5% consolidated revenue growth and 46.9% fixed gross margin | 112.54 |
| Earlier FCFF DCF | FY2025 cash flow; five-year FCFF growth 0.57%; WACC 8.91%; terminal growth 2%; 15,004.697 million shares | 90.66 |

The original research memo specified October 31, 2025 as its valuation date. The models use FY2025-based forecast timing. The later saved quote is dated September 24, 2026; no common-date revaluation has been completed. The differing methods, growth definitions and share counts must not be averaged into one estimate.

FCFE is discounted at the cost of equity and directly values equity cash flows. The terminal schedule assumes debt maturities are refinanced and includes replacement investment for other amortized assets. The model does not subtract debt again. It also does not separately add excess cash and securities; that treatment requires review before claiming a complete market-date equity valuation.

The earlier FCFF model discounts cash flow available to capital providers at WACC. Its enterprise-to-equity bridge is **1,326,590.67 + 132,420 cash/investments − 98,657 debt = 1,360,353.67 equity value**, all in millions. Dividing by 15,004.697 million shares gives $90.66.

The saved later market reference is **$335.92, September 24, 2026, 16:00 EDT**, recorded from [Yahoo Finance Japan](https://finance.yahoo.co.jp/quote/AAPL). It is not a current quote. The earlier reverse DCF separately used **$326**, with its quote date unresolved. Holding WACC 8.91%, terminal growth 2%, starting FCFF, cash, debt and shares fixed, the saved reverse DCF requires **33.70% annual FCFF growth for five years**. That is one conditional set of expectations consistent with price, not a literal market forecast. It cannot independently identify growth, margins and discount rates from one price.

**Peer comparison unresolved:** the initial report proposed P/E, EV/EBIT and EV/FCF, but no completed peer table or supported peer valuation was found. Microsoft and Alphabet are possible research candidates, not established results. Their different business mixes would need explicit treatment. Multiples measure relative market pricing; DCF depends on forecast cash flows and required returns. Missing peer work is not evidence that P/E is inherently meaningless for Apple.

## 5. Sensitivity and drivers

Each scenario changes one independent input from the new Services base. Values and signed changes below use full-precision calculations before rounding. Operating profit and FCFE are FY2030, USD millions.

| Scenario | Services growth | Cost of equity | Operating profit | FCFE | Value/share | Change/share |
|---|---:|---:|---:|---:|---:|---:|
| Base | 10% | 10% | 190,523.8 | 153,571.7 | 125.52 | — |
| Lower required return | 10% | 8% | 190,523.8 | 153,571.7 | 173.08 | +47.56 |
| Stability shock | 10% | 12% | 190,523.8 | 153,571.7 | 98.07 | −27.45 |
| Slower Services | 5% | 10% | 169,919.4 | 135,259.0 | 112.56 | −12.97 |
| Faster Services | 15% | 10% | 215,235.1 | 175,689.9 | 141.00 | +15.48 |

**Causal path:** Services growth → Services revenue → category gross profit and consolidated mix → SG&A, R&D, taxes and working capital → FCFE → discounted equity value. Base FY2030 consolidated gross margin is 48.74%; the 5% and 15% Services cases yield 46.91% and 50.65%. Category margins remain fixed.

The cost-of-equity test changes present value without changing statements. It approximates a perceived-stability shock only through investors' required returns; a real shock could also reduce sales or margins. The value span is **75.01** for cost of equity and **28.44** for Services growth. That ranking applies only to these selected ranges, not probabilities or universal economic importance.

The saved model tests pass all balance checks and restore the base exactly. A model limitation is fixed capex despite changing growth. Another is aggregate working-capital ratios, which may overstate Services financing benefits. Cost of equity is a valuation input, so the chosen pair does not literally satisfy Lab 11's two-operating-driver requirement. The independent pre-run prediction and actual Lab 11 partner review were also not supplied.

## 6. Interpretation and next investigation

The model supports a conditional **watch / do not initiate at the saved reference price** conclusion. This is a proposed update to the original buy thesis, grounded in the existing results rather than a claim that the student already delivered these exact words in class. The strongest individual sensitivity case is $173.08; combined scenarios were not tested here.

Investigate Services growth durability, regulatory exposure, category reinvestment and working capital, an evidence-based discount rate, and the treatment of cash, securities, buybacks and dilution. Then align the forecast, share count and market price to one date and complete the peer comparison. A lower price or stronger supportable future cash flows could change the conclusion. A high price indicates demanding possible expectations; it does not prove those expectations will occur.

## Partner review: NVIDIA — actual notes supplied

The following records the student's notes about the partner's presentation. Partner figures are reported claims, not independently verified NVIDIA facts.

| Area | What the partner explained |
|---|---|
| Selection | NVIDIA was selected because of AI and data-center growth; the initial view was buy. |
| Business | GPUs are important to AI infrastructure; demand is driven by the AI industry. |
| Forecast | Revenue during 2028–2031 depends on data-center demand. The partner described Data Center as about 90% of revenue; period/source not supplied. |
| Valuation | Model value $112/share versus reported market price $230/share. She attributed the gap to high AI expectations not captured in the pro-forma. The model's valuation date, method, discount rate, terminal growth, and share basis were not supplied. |
| Financial position | She highlighted little/no debt, substantial cash and a $130 billion buyback. Exact debt definition, source dates, and authorization versus execution remain unverified. |
| Sensitivity | Revenue growth varied ±5%; whether this means percentage points or relative percent, and the resulting values, were not supplied. |
| Interpretation | NVIDIA should continue growing as AI infrastructure expands. |

### Reviewer record

**Actual question asked, supplied by the student:** “Do you predict that AI investment will slow, and if it does, how will this affect your valuation?” This addresses sensitivity and interpretation by connecting the industry demand outlook to the revenue assumption and valuation. The partner's answer was not supplied. The specific unresolved issue is whether slower AI investment would reduce forecast revenue growth, margins or both, and what value the revised assumptions would produce.

**Explanation back, drafted from the notes:** Your thesis is that AI data-center demand will drive NVIDIA's revenue and cash flow. Your model values shares at $112, below your reported market price of $230. You attribute the difference to stronger market expectations. Revenue growth is the main driver; the biggest limitation is that the buy thesis has not yet been reconciled with the model's lower value. Presenter confirmation or correction of this explanation was not supplied.

**Evidence-backed strength, proposed feedback:** The presentation connects a specific business demand driver—AI data-center investment—to revenue growth and a related sensitivity test.

**Specific improvement, proposed feedback:** Show the growth needed to support $230 with other valuation assumptions held fixed, then identify evidence supporting that growth. Distinguish buyback authorization from completed repurchases; buybacks use cash and are not a separate addition to operating value.

**Arithmetic check prepared after the discussion:** (112 / 230 − 1) × 100 = **−51.30%**. The reported model value is 51.30% below the reported price. This uses the supplied figures only; it is not a jointly completed source or model check.

| Required question area | Specific follow-up prepared from the notes | Actual exchange status |
|---|---|---|
| Selection and evidence | Which filing and period support Data Center being about 90% of revenue, and how does that concentration affect your selection thesis? | Asked question and response not supplied. |
| Model and valuation | What growth would justify $230 with the discount rate, margins and terminal growth fixed, and how are cash, debt and buybacks treated? | Asked question and response not supplied. |
| Sensitivity and interpretation | Actual question: Do you predict that AI investment will slow, and if it does, how will this affect your valuation? | Question confirmed; partner's answer not supplied. Follow-up to clarify: does ±5% mean percentage points or a relative change, and what values result? |

**Joint evidence check:** No source opened together or traced model calculation was documented. Resolve by recording the actual source/line or input-to-output calculation, result, and whether it supported the claim. Do not substitute the arithmetic above for an undocumented classroom activity.

### Presenter record: Apple

Actual Lab 12 questions received, answers, and feedback about Apple have not been supplied. Earlier Lab 10 growth discussions are not relabeled as Lab 12 evidence. Record the question, the answer actually given or the precise unresolved gap, and the resulting next action.

### Keep / revise / investigate — proposed post-review reflection

- **Keep:** Separate Products and Services and retain the audited category margins. This ties the operating story to identifiable financial evidence.
- **Revise:** State the recommendation conditionally and distinguish business growth from price justification. The partner's $112 versus $230 gap illustrates why a growth thesis alone cannot resolve a valuation gap.
- **Investigate:** Reverse-implied growth, common valuation dates, Services reinvestment and working capital, and peer comparisons. These are priorities, not model repairs already performed.
- **Effect on conclusion:** The supplied NVIDIA notes introduce no new Apple operating evidence, so they do not change the saved Apple valuation. They sharpen the research priority: explain what a market price requires, then test whether the evidence supports it.
- **Reflection to personalize:** The contrast between a buy thesis and a below-market model value highlights the distinction between company growth and investment return. No specific question that caused the student to reconsider has been documented; add the actual question rather than claim a proposed one was asked.

## Evidence files and reproduction

The package reuses the existing models and outputs without changing their assumptions or rerunning them. [Evidence index](evidence/README.md) identifies all supporting files. No new slide deck or recording is required by the handout.

Run from the evidence folder:

```text
python apple_services_sensitivity.py --services-low 5 --services-base 10 --services-high 15
python apple_proforma.py
python verify_apple_proforma.py
```

## Checkout status

The six-stop analysis, existing code/results, supplied NVIDIA presentation notes, and the actual AI-investment-slowdown question are assembled. Still unresolved: the partner's answer, questions/exchanges in the other two reviewer areas, Apple questions/answers as presenter, joint evidence check, confirmation/correction of the explanation back, feedback actually delivered/received, and the student's personal reflection. The peer comparison and valuation-date alignment also remain explicitly scoped gaps. The course requests GitHub links; this local package does not claim a successful GitHub upload.
