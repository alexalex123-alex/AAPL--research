# Lab 11 — Apple Services growth and perceived stability

**Current version: replaces the iPhone-margin test.** The operating driver is Services revenue growth, with its higher gross margin flowing through the revenue mix. The other requested driver is perceived stability, represented by cost of equity. No iPhone-specific margin is assumed or varied.

## Completion status

The requested scenario analysis, signed differences, spans, visible statements, checks, reproducible code and explanatory notes are complete. Three course requirements remain distinct: **cost of equity is not the required second operating driver; no independent pre-run student prediction was supplied; and actual Lab 11 partner notes were not supplied.** No claim is made that these requirements have been completed.

## D — driver question

How much do faster growth in Apple's high-margin Services business and changes in investors' required return affect forecast profit, FCFE and value per share, over the selected ranges?

## Article: what informs the model?

The [September 28, 2026 opinion article by Gian Estrada](https://finance.yahoo.com/markets/stocks/articles/opinion-apple-gangster-move-boost-155254919.html) argues that a larger Services mix supports profitability and that more predictable customer relationships can support valuation. It also cautions that an iPhone lease arranged through Klarna does not necessarily change how Apple recognizes its own revenue. These are separate operating and valuation ideas; the model tests them separately rather than assuming a financing plan automatically becomes Services revenue or automatically earns a valuation premium.

The article's quoted margins and market multiples are not adopted as forecast facts. Category revenue and gross profit are anchored in Apple's 10-K; the growth ranges and required returns below are judgments selected by the user. This is a test of the article's economic mechanism, not an endorsement or a reproduction of its market-multiple valuation.

## R — reported anchors and labeled assumptions

All financial amounts are USD millions unless indicated. [Apple FY2025 10-K, income statement p. 29 and MD&A pp. 23–24](https://www.sec.gov/Archives/edgar/data/320193/000032019325000079/aapl-20250927.htm).

| Value | Label | Reason |
|---|---|---|
| FY2025 Services revenue **109,158**, gross profit **82,314** | History | Reported category amounts establish the starting Services business. |
| FY2025 Products revenue **307,003**, gross profit **112,887** | History | Reported category amounts establish the remaining product business; Products includes all hardware categories, not just iPhone. |
| Services gross margin **82,314 / 109,158 = approximately 75.41%**, held constant | Judgment | Hold the reported starting profitability constant so the test isolates growth rather than an additional margin improvement. |
| Products gross margin **112,887 / 307,003 = approximately 36.77%**, held constant | Judgment | Keep product profitability fixed so only Services growth changes in the operating tests. |
| Services annual revenue growth: **5% / 10% base / 15%** in FY2026–FY2030 | Judgment, user-selected | A slower-growth, central and stronger-growth comparison. The article does not supply this forecast range; it is not management guidance or a confidence interval. |
| Products annual revenue growth: **5% in every year**, unchanged across scenarios | Judgment | Retain the original model's 5% growth assumption for Products; all variation in the operating comparison comes from Services. |
| Cost of equity: **8% / 10% base / 12%** | Judgment, user-selected | Compare lower required return with a lasting perceived-stability shock that raises required return. This is a sensitivity range, not an estimated CAPM result. |
| Consolidated revenue and gross margin: **calculated from the two categories** | Judgment about model structure | Do not hold consolidated margin fixed when a higher-margin business changes its share of sales. |
| Inventory: **Products cost of sales × (5,718 / 194,116)** | Judgment using history | Inventory follows product costs; Services growth alone should not create physical product inventory. The calibrated inventory-days ratio is 5,718 / 194,116 × 365. |
| Other working-capital accounts: original FY2025 ratios to **total revenue** | Judgment | Preserve the remaining Lab 10 account rules for comparability. This aggregate treatment may overstate working-capital financing benefits from Services and needs refinement before a stronger economic conclusion. |
| SG&A / gross profit **14.1%**; R&D / revenue **8.3%**; tax **16%** | Judgment, retained | Preserve the saved expense and tax assumptions; linked dollar expenses and taxes recalculate with category growth. |
| Capex **12,715**; PP&E depreciation ratio **8,000 / 49,834**; other D&A **3,698** | Judgment / historical calibration, retained | Preserve the original reinvestment and D&A schedule rather than mix a capital-spending shock into the growth test. Maintaining fixed capex at higher Services growth is a limitation to investigate. |
| Net other expense **321**; term-debt repayment **10,932**; dividends **15,421**; target buybacks **90,711**; cash floor **25,000** | Judgment, retained | Preserve the original nonoperating, financing and liquidity assumptions. Buybacks adjust downward if required by the cash floor. |
| Terminal growth **2.5%**; share denominator **14,773.260 million** | Judgment / history, retained | Keep valuation comparisons on the same long-run growth and FY2025 share count. Services does not grow at 10% or 15% forever: the normalized total-company terminal cash flow grows at 2.5%. |

All remaining opening balances and account treatments are inherited from Lab 10: securities, deferred-tax assets, tax payable, commercial paper and other long-term liabilities stay flat; other non-tax long-term assets decline with the other-D&A residual; no separate stock-compensation addback is taken. No forward company guidance is claimed for these policies.

The Services range is ±5 **percentage points** around 10%, not ±5% relative. The cost-of-equity range is ±2 percentage points around 10%. Services growth is applied annually through FY2030; the cost of equity applies to the discount factors and terminal capitalization.

## Important: a revised base, not an unexplained change to Lab 10

The saved Lab 10 model used 5% total revenue growth and 46.9% fixed gross margin, producing **$112.54** per share. This extension separates Products and Services, uses exact reported category margins, and assigns **10% Services growth versus 5% Products growth** in the new base. Its base is therefore **$125.52**, not $112.54.

The 5%-Services scenario, where both businesses grow at 5%, gives **$112.56**, close to the old result. The small remaining difference comes from exact reported margins instead of the rounded 46.9% and the inventory calibration to product costs. Do not compare one scenario's change against the old base: all differences below use the new segmented base. The original Lab 10 file is unchanged.

## I / V — one-input-at-a-time sensitivity table

Outputs are FY2030 operating profit and **FCFE**, in USD millions; value is USD per share. Each run starts with a fresh copy of the same new base. Category margins are fixed in every run.

| Scenario | Services growth | Cost of equity | Operating profit | FCFE | Value/share |
|---|---:|---:|---:|---:|---:|
| Base | 10% | 10% | 190,523.8 | 153,571.7 | $125.52 |
| More stable: cost of equity 8% | 10% | 8% | 190,523.8 | 153,571.7 | $173.08 |
| Stability shock: cost of equity 12% | 10% | 12% | 190,523.8 | 153,571.7 | $98.07 |
| Services growth 5% | 5% | 10% | 169,919.4 | 135,259.0 | $112.56 |
| Services growth 15% | 15% | 10% | 215,235.1 | 175,689.9 | $141.00 |

### Revenue mix explains the operating effect

| Services annual growth | FY2030 Services revenue, $m | Services share of total revenue | Consolidated gross margin |
|---|---:|---:|---:|
| 5% | 139,316.3 | 26.23% | 46.91% |
| 10% | 175,800.1 | 30.97% | 48.74% |
| 15% | 219,555.7 | 35.91% | 50.65% |

The high margin itself is not the varied driver. Services' **growth rate** changes, increasing or decreasing its mix share while each category's margin stays fixed. That is the mechanism requested from the article.

### Signed changes from the new base

| Scenario | Operating-profit change, $m | FCFE change, $m | Value/share change |
|---|---:|---:|---:|
| More stable: cost of equity 8% | +0.0 | +0.0 | $+47.56 |
| Stability shock: cost of equity 12% | +0.0 | +0.0 | $-27.45 |
| Services growth 5% | -20,604.4 | -18,312.7 | $-12.97 |
| Services growth 15% | +24,711.3 | +22,118.2 | $+15.48 |

Example using displayed results: **175,689.9 − 153,571.7 = +22,118.2 million** of final-year FCFE in the 15% Services case. The code uses full precision before rounding. This is a worked check to reproduce personally, not a claim of a completed student or partner check.

### Visible accounting and restored-base checks

| Scenario | FY2026 gap | FY2027 gap | FY2028 gap | FY2029 gap | FY2030 gap | Lowest cash, $m |
|---|---:|---:|---:|---:|---:|---:|
| Base | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 40,136.9 |
| More stable: cost of equity 8% | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 40,136.9 |
| Stability shock: cost of equity 12% | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 40,136.9 |
| Services growth 5% | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 36,960.9 |
| Services growth 15% | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 | 43,312.9 |

All 25 forecast-year checks pass; cash exceeds the 25,000 floor and FCFE stays positive. No revolver or buyback reduction is needed in these runs. The script checks that only the chosen independent input changes, verifies the Services earnings bridge, confirms product inventory is unchanged across Services-only runs, and reruns the new base at the end. The full restored-base statements and value match exactly. Accounting tolerance is 0.000001 million.

If a future run fails accounting, it is flagged invalid and not used for a complete ranking. Negative explicit cash flows retain their signs; nonpositive terminal cash flow or an invalid discount-rate/growth relationship makes valuation unavailable rather than forcing a terminal value.

## E — which driver matters over these ranges?

| Driver | Operating-profit span, $m | FCFE span, $m | Value/share span |
|---|---:|---:|---:|
| Stability | 0.0 | 0.0 | $75.01 |
| Services growth | 45,315.7 | 40,430.9 | $28.44 |

**Over these ranges, Services growth drives operating profit and cash flow, while the stability/required-return test produces the larger per-share valuation span.** The required-return span is approximately 75.01 per share versus 28.44 for Services growth. This is conditional on the chosen range widths and the model, not an inherent ranking or a probability statement.

### Trace the links

1. Services revenue compounds from 109,158 at the selected rate. Products revenue grows at a fixed 5% from 307,003.
2. Each category's revenue is multiplied by its own fixed gross margin. Faster Services growth both increases total revenue and increases the weight of the more profitable category.
3. SG&A rises with gross profit and R&D rises with total revenue. The incremental Services operating-profit formula is `change in Services revenue × [Services margin × (1 − SG&A/GP) − R&D/revenue]`. The script independently verifies this link.
4. Taxes, net income and total-revenue-linked working-capital accounts recalculate. Product inventory is unchanged because Products costs are unchanged. Under the inherited negative working-capital structure, faster growth also produces extra working-capital financing; that is a model assumption to scrutinize, not a discovered Services-specific fact.
5. FCFE rises, then explicit cash flows and the normalized terminal cash flow are discounted. The separate stability cases change only cost of equity; identical statements produce different present values.

Do not simultaneously lower the discount rate in the faster-Services case: that would combine two independent changes. Neither a revenue multiple nor an automatic recurring-revenue premium is added on top of the FCFE valuation. A real stability shock might also damage sales or margins, but this test isolates required return.

## Learn-on-your-own answers and reflection prompts

**One-at-a-time sensitivity:** Change one independent driver while resetting all others to base and recalculating dependent revenue, margins, expenses, cash flows and balance-sheet accounts.

**Why ranges matter:** Spans reflect both the economic relationships and the size of the selected shocks. Testing wider Services growth or narrower cost of equity could change the ranking.

**Why these are not probabilities:** The three inputs are selected scenarios with no likelihood weights. The table does not prove the endpoints are likely or that the market must adopt the model's value.

**Research priority:** Validate the persistence of Services growth, its mix and gross-margin economics, and the reinvestment and working-capital needs associated with scaling it. Separately support the required-return range rather than equating recurring revenue with guaranteed stability. Historical source anchors are traceable; future growth and risk remain judgments.

**Reflection to write personally:** Which result surprised you—the effect of Services mix on consolidated margin, or the size of the discount-rate effect despite unchanged operating results? Use the numbers above and your own reaction; no personal reaction is invented here.

## Locked prediction and partner evidence — not supplied

The user selected 5%/10%/15% Services growth before these runs. That selection is not itself the course's Locked Changed-Input Record: no student-authored prediction made with AI closed, timestamp, rough expected output change or pre-run partner unit check was provided. No timestamp is backdated.

| Required record | Status |
|---|---|
| Pre-run timestamp / Git commit, old → new input and units | Not supplied |
| Expected direction, rough size and reason | Not supplied |
| Partner's pre-run unit and one-input check | Not confirmed |
| Actual result | Available in the tables |
| Prediction error and explanation | Cannot evaluate without the genuine prior prediction |
| Student's change or no-change conclusion / research priority | To be written personally |
| Actual partner question, response and check on their model | Not supplied for Lab 11 |

These Services outputs have now been observed. To satisfy the locked-record requirement, choose a fresh untested input change, close AI and write the prediction before running it. The earlier Lab 10 growth discussion is not reused as a Lab 11 Services review.

Suggested review questions, not an invented exchange: “Does Services need additional capex or different working-capital ratios to sustain this growth?” and “What supports 8%–12% cost of equity?” Have the reviewer recompute the 15%-Services FCFE difference and check that required return stayed at 10%.

## Fit to the lab and submission

Lab 11 asks for **two operating drivers already in the model**. This extension introduces one operating driver (Services growth) and retains the user's requested valuation driver (cost of equity). It provides the requested analysis, but to meet the literal operating-driver requirement, select and test a second operating driver or obtain instructor acceptance of the substitution. No instructor acceptance is claimed.

The bundle includes the segmented engine, sensitivity runner, full scenario statements as JSON, visible output with new-base statements, and this report. No slide deck is required by the supplied Lab 11 worksheet. No GitHub upload is claimed.

```bash
python apple_services_sensitivity.py --services-low 5 --services-base 10 --services-high 15
```

Keep the runner beside `apple_services_proforma.py`. The new base resets and restores within this analysis; the original Lab 10 files remain separate and unchanged. The old September 24 market quote is not used as a current quote in this report.
