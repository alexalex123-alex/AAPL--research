# Apple (AAPL): five years of financial statements

Fiscal years 2021–2025, the five completed fiscal years as of September 24, 2026. Amounts are **USD millions**, except earnings per share (USD) and weighted-average shares (thousands). Parentheses mean negative amounts. These are reported historical figures, not projections.

| Fiscal year | FY2021 | FY2022 | FY2023 | FY2024 | FY2025 |
|---|---|---|---|---|---|
| Year ended | Sep 25, 2021 | Sep 24, 2022 | Sep 30, 2023 | Sep 28, 2024 | Sep 27, 2025 |

## Income statements

Sources: [2025 Form 10-K, p. 29](https://www.sec.gov/Archives/edgar/data/320193/000032019325000079/aapl-20250927.htm) for FY2023–2025; [2023 Form 10-K, p. 28](https://www.sec.gov/Archives/edgar/data/320193/000032019323000106/aapl-20230930.htm) for FY2021–2022.

| Line item | FY2021 | FY2022 | FY2023 | FY2024 | FY2025 |
|---|---:|---:|---:|---:|---:|
| Product revenue | 297,392 | 316,199 | 298,085 | 294,866 | 307,003 |
| Services revenue | 68,425 | 78,129 | 85,200 | 96,169 | 109,158 |
| **Total revenue** | **365,817** | **394,328** | **383,285** | **391,035** | **416,161** |
| Product cost of sales | 192,266 | 201,471 | 189,282 | 185,233 | 194,116 |
| Services cost of sales | 20,715 | 22,075 | 24,855 | 25,119 | 26,844 |
| Total cost of sales | 212,981 | 223,546 | 214,137 | 210,352 | 220,960 |
| **Gross profit** | **152,836** | **170,782** | **169,148** | **180,683** | **195,201** |
| Research and development | 21,914 | 26,251 | 29,915 | 31,370 | 34,550 |
| Selling, general and administrative | 21,973 | 25,094 | 24,932 | 26,097 | 27,601 |
| Total operating expenses | 43,887 | 51,345 | 54,847 | 57,467 | 62,151 |
| **Operating income** | **108,949** | **119,437** | **114,301** | **123,216** | **133,050** |
| Other income / (expense), net | 258 | (334) | (565) | 269 | (321) |
| Pretax income | 109,207 | 119,103 | 113,736 | 123,485 | 132,729 |
| Income tax provision | 14,527 | 19,300 | 16,741 | 29,749 | 20,719 |
| **Net income** | **94,680** | **99,803** | **96,995** | **93,736** | **112,010** |
| Basic EPS ($) | 5.67 | 6.15 | 6.16 | 6.11 | 7.49 |
| Diluted EPS ($) | 5.61 | 6.11 | 6.13 | 6.08 | 7.46 |
| Weighted-average basic shares (thousands) | 16,701,272 | 16,215,963 | 15,744,231 | 15,343,783 | 14,948,500 |
| Weighted-average diluted shares (thousands) | 16,864,919 | 16,325,819 | 15,812,547 | 15,408,095 | 15,004,697 |

## Balance sheets

Sources: [2025 Form 10-K, p. 31](https://www.sec.gov/Archives/edgar/data/320193/000032019325000079/aapl-20250927.htm) for FY2024–2025; [2023 Form 10-K, p. 30](https://www.sec.gov/Archives/edgar/data/320193/000032019323000106/aapl-20230930.htm) for FY2022–2023; [2022 Form 10-K, p. 31](https://www.sec.gov/Archives/edgar/data/320193/000032019322000108/aapl-20220924.htm) for FY2021. Balances are at each fiscal year-end.

| Line item | FY2021 | FY2022 | FY2023 | FY2024 | FY2025 |
|---|---:|---:|---:|---:|---:|
| **Current assets** | | | | | |
| Cash and cash equivalents | 34,940 | 23,646 | 29,965 | 29,943 | 35,934 |
| Current marketable securities | 27,699 | 24,658 | 31,590 | 35,228 | 18,763 |
| Accounts receivable, net | 26,278 | 28,184 | 29,508 | 33,410 | 39,777 |
| Vendor non-trade receivables | 25,228 | 32,748 | 31,477 | 32,833 | 33,180 |
| Inventories | 6,580 | 4,946 | 6,331 | 7,286 | 5,718 |
| Other current assets | 14,111 | 21,223 | 14,695 | 14,287 | 14,585 |
| **Total current assets** | **134,836** | **135,405** | **143,566** | **152,987** | **147,957** |
| **Non-current assets** | | | | | |
| Non-current marketable securities | 127,877 | 120,805 | 100,544 | 91,479 | 77,723 |
| Property, plant and equipment, net | 39,440 | 42,117 | 43,715 | 45,680 | 49,834 |
| Other non-current assets | 48,849 | 54,428 | 64,758 | 74,834 | 83,727 |
| Total non-current assets | 216,166 | 217,350 | 209,017 | 211,993 | 211,284 |
| **Total assets** | **351,002** | **352,755** | **352,583** | **364,980** | **359,241** |
| **Current liabilities** | | | | | |
| Accounts payable | 54,763 | 64,115 | 62,611 | 68,960 | 69,860 |
| Other current liabilities | 47,493 | 60,845 | 58,829 | 78,304 | 66,387 |
| Deferred revenue | 7,612 | 7,912 | 8,061 | 8,249 | 9,055 |
| Commercial paper | 6,000 | 9,982 | 5,985 | 9,967 | 7,979 |
| Current term debt | 9,613 | 11,128 | 9,822 | 10,912 | 12,350 |
| **Total current liabilities** | **125,481** | **153,982** | **145,308** | **176,392** | **165,631** |
| **Non-current liabilities** | | | | | |
| Non-current term debt | 109,106 | 98,959 | 95,281 | 85,750 | 78,328 |
| Other non-current liabilities | 53,325 | 49,142 | 49,848 | 45,888 | 41,549 |
| Total non-current liabilities | 162,431 | 148,101 | 145,129 | 131,638 | 119,877 |
| **Total liabilities** | **287,912** | **302,083** | **290,437** | **308,030** | **285,508** |
| **Shareholders' equity** | | | | | |
| Common stock and additional paid-in capital | 57,365 | 64,849 | 73,812 | 83,276 | 93,568 |
| Retained earnings / (accumulated deficit) | 5,562 | (3,068) | (214) | (19,154) | (14,264) |
| Accumulated other comprehensive income / (loss) | 163 | (11,109) | (11,452) | (7,172) | (5,571) |
| **Total shareholders' equity** | **63,090** | **50,672** | **62,146** | **56,950** | **73,733** |
| **Total liabilities and equity** | **351,002** | **352,755** | **352,583** | **364,980** | **359,241** |

## Cash flow statements

Sources: [2025 Form 10-K, p. 33](https://www.sec.gov/Archives/edgar/data/320193/000032019325000079/aapl-20250927.htm) for FY2023–2025; [2023 Form 10-K, p. 32](https://www.sec.gov/Archives/edgar/data/320193/000032019323000106/aapl-20230930.htm) for FY2021–2022. Signs below represent the reported effect on cash. Beginning and ending cash include restricted cash and cash equivalents.

| Line item | FY2021 | FY2022 | FY2023 | FY2024 | FY2025 |
|---|---:|---:|---:|---:|---:|
| Beginning cash, including restricted cash | 39,789 | 35,929 | 24,977 | 30,737 | 29,943 |
| **Operating activities** | | | | | |
| Net income | 94,680 | 99,803 | 96,995 | 93,736 | 112,010 |
| Depreciation and amortization | 11,284 | 11,104 | 11,519 | 11,445 | 11,698 |
| Share-based compensation expense | 7,906 | 9,038 | 10,833 | 11,688 | 12,863 |
| Other reconciliation adjustments | (4,921) | 1,006 | (2,227) | (2,266) | (89) |
| Change in accounts receivable | (10,125) | (1,823) | (1,688) | (3,788) | (6,682) |
| Change in vendor non-trade receivables | (3,903) | (7,520) | 1,271 | (1,356) | (347) |
| Change in inventories | (2,642) | 1,484 | (1,618) | (1,046) | 1,400 |
| Change in other current and non-current assets | (8,042) | (6,499) | (5,684) | (11,731) | (9,197) |
| Change in accounts payable | 12,326 | 9,448 | (1,889) | 6,020 | 902 |
| Change in other current and non-current liabilities | 7,475 | 6,110 | 3,031 | 15,552 | (11,076) |
| **Cash from operating activities** | **104,038** | **122,151** | **110,543** | **118,254** | **111,482** |
| **Investing activities** | | | | | |
| Purchases of marketable securities | (109,558) | (76,923) | (29,513) | (48,656) | (24,407) |
| Maturities of marketable securities | 59,023 | 29,917 | 39,686 | 51,211 | 40,907 |
| Sales of marketable securities | 47,460 | 37,446 | 5,828 | 11,135 | 12,890 |
| Purchases of PP&E (capital expenditures) | (11,085) | (10,708) | (10,959) | (9,447) | (12,715) |
| Other investing activities | (385) | (2,086) | (1,337) | (1,308) | (1,480) |
| **Cash from / (used in) investing** | **(14,545)** | **(22,354)** | **3,705** | **2,935** | **15,195** |
| **Financing activities** | | | | | |
| Taxes on net share settlement of equity awards | (6,556) | (6,223) | (5,431) | (5,441) | (5,960) |
| Dividends and dividend equivalents paid | (14,467) | (14,841) | (15,025) | (15,234) | (15,421) |
| Common stock repurchases | (85,971) | (89,402) | (77,550) | (94,949) | (90,711) |
| Term-debt issuance proceeds, net | 20,393 | 5,465 | 5,228 | 0 | 4,481 |
| Term-debt repayments | (8,750) | (9,543) | (11,151) | (9,958) | (10,932) |
| Commercial-paper proceeds / (repayments), net | 1,022 | 3,955 | (3,978) | 3,960 | (2,032) |
| Other financing activities | 976 | (160) | (581) | (361) | (111) |
| **Cash used in financing activities** | **(93,353)** | **(110,749)** | **(108,488)** | **(121,983)** | **(120,686)** |
| **Net change in cash, including restricted cash** | **(3,860)** | **(10,952)** | **5,760** | **(794)** | **5,991** |
| **Ending cash, including restricted cash** | **35,929** | **24,977** | **30,737** | **29,943** | **35,934** |
| Supplemental: cash income taxes paid, net | 25,385 | 19,573 | 18,679 | 26,102 | 43,369 |

## Reading and reconciliation notes

- FY2023 had 53 weeks; FY2021 and FY2022 had 52 weeks. Fiscal years end on the last Saturday in September. [2023 Form 10-K, Note 1](https://www.sec.gov/Archives/edgar/data/320193/000032019323000106/aapl-20230930.htm).
- This compilation includes the numerical lines on the three primary statements, with shortened labels and aligned categories. The filing notes, stock authorization details, commitments and contingencies disclosures, and separate comprehensive-income and equity-movement statements remain in the linked filings.
- FY2021–2023 balance-sheet cash excludes restricted cash included in the cash-flow totals. The differences are 989, 1,331 and 772, respectively; FY2024–2025 differences are zero. These differences are calculated from the reported statement totals.
- Operating cash flow changes need not equal simple differences between balance-sheet accounts because of noncash items and other reconciling effects. Preserve the reported cash-flow figures when building historical inputs.
- The 2025 cash-flow statement no longer separately presents supplemental cash interest paid. The 2023 filing reports 2,687, 2,865 and 3,803 for FY2021–2023, respectively; these are supplemental disclosures, not additional deductions from reported operating cash flow.
- Arithmetic checks performed: revenue less costs equals gross profit; gross profit less operating expenses equals operating income; pretax income less taxes equals net income; asset and liability subtotals sum; assets equal liabilities plus equity; each cash-flow section sums; and beginning cash plus net cash change equals ending cash for every year.
