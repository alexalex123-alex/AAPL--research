"""Apple Services/Products extension of the Lab 10 model; standard library only.
FY2025 category revenue and gross profit are from Apple FY2025 10-K pp. 23-24.
The original apple_proforma.py is unchanged. This file has a NEW segmented base.
Services/product margins are held constant; consolidated margin is calculated.
Inventory is linked to Products cost of sales; other WC keeps the original total-sales ratios.
"""
import math

A = dict(product_growth=.05, services_growth=.10,
         product_margin=112887/307003, services_margin=82314/109158, sga_gp=.141, rd_sales=.083,
         dep_ratio=8000/49834, other_amort=3698., capex=12715., tax=.16,
         inventory_days=5718/194116*365, net_other=-321., repayment=10932.,
         dividends=15421., buybacks=90711., cash_floor=25000.,
         ke=.10, terminal_growth=.025, shares=14773.260)
OPENING = dict(year=2025, revenue=416161., products_revenue=307003., services_revenue=109158., cash=35934., securities_current=18763.,
    receivables=39777., vendor_receivables=33180., inventory=5718., other_current_assets=14585.,
    securities_long=77723., ppe=49834., deferred_tax_assets=20777., other_long_assets=62950.,
    payables=69860., tax_payable=13016., other_current_liabilities=53371., deferred_revenue=9055.,
    commercial_paper=7979., debt_current=12350., debt_long=78328., other_long_liabilities=41549.,
    equity=73733.)
ASSETS = ('cash','securities_current','receivables','vendor_receivables','inventory',
          'other_current_assets','securities_long','ppe','deferred_tax_assets','other_long_assets')
LIABILITIES = ('payables','tax_payable','other_current_liabilities','deferred_revenue',
               'commercial_paper','debt_current','debt_long','other_long_liabilities')
WC_ASSETS = ('receivables','vendor_receivables','other_current_assets')
WC_LIABILITIES = ('payables','other_current_liabilities','deferred_revenue')


def gap(r):
    return sum(r[k] for k in ASSETS)-sum(r[k] for k in LIABILITIES)-r['equity']


def wc(r):
    return sum(r[k] for k in WC_ASSETS)-sum(r[k] for k in WC_LIABILITIES)


def assert_balanced(rows, a=A):
    for r in rows:
        name=f"FY{int(r['year'])}E"
        if not all(math.isfinite(v) for v in r.values()):
            raise ValueError(f'{name}: non-finite model value')
        g=gap(r)
        if abs(g)>1e-6:
            raise ValueError(f'{name}: assets - liabilities - equity gap {g:+,.1f}')
        if r['cash']<a['cash_floor']-1e-6:
            raise ValueError(f"{name}: cash-floor gap {r['cash']-a['cash_floor']:+,.1f}")
        for k in ASSETS+LIABILITIES:
            if r[k]<-1e-6:
                raise ValueError(f'{name}: negative {k}: {r[k]:,.1f}')
        if abs(r['cash']-r['opening_cash']-r['cfo']-r['cfi']-r['cff'])>1e-6:
            raise ValueError(f'{name}: cash-flow reconciliation failed')


def project(a=A):
    if abs(gap(OPENING))>1e-6:
        raise ValueError('Opening balance sheet does not balance')
    rows=[]
    p=OPENING.copy()
    for year in range(2026,2031):
        r=p.copy()
        r['year']=year
        r['products_revenue']=p['products_revenue']*(1+a['product_growth'])
        r['services_revenue']=p['services_revenue']*(1+a['services_growth'])
        r['revenue']=r['products_revenue']+r['services_revenue']
        r['products_gp']=r['products_revenue']*a['product_margin']
        r['services_gp']=r['services_revenue']*a['services_margin']
        r['gross_profit']=r['products_gp']+r['services_gp']
        r['products_cogs']=r['products_revenue']-r['products_gp']
        r['cogs']=r['revenue']-r['gross_profit']
        r['services_share']=r['services_revenue']/r['revenue']
        r['gross_margin']=r['gross_profit']/r['revenue']
        r['sga']=r['gross_profit']*a['sga_gp']
        r['rd']=r['revenue']*a['rd_sales']
        # Reported margins/expense ratios ALREADY include D&A. No second deduction.
        r['operating_income']=r['gross_profit']-r['sga']-r['rd']
        r['net_other']=a['net_other']
        r['pretax']=r['operating_income']+r['net_other']
        r['tax']=max(0.,r['pretax'])*a['tax']
        r['net_income']=r['pretax']-r['tax']
        r['depreciation']=p['ppe']*a['dep_ratio']
        r['other_amort']=a['other_amort']
        r['da']=r['depreciation']+r['other_amort']
        r['capex']=a['capex']
        r['ppe']=p['ppe']+r['capex']-r['depreciation']
        # Explicit simplifying allocation of non-PP&E amortization, not a reported schedule.
        r['other_long_assets']=p['other_long_assets']-r['other_amort']
        for key in WC_ASSETS+WC_LIABILITIES:
            r[key]=OPENING[key]/OPENING['revenue']*r['revenue']
        r['inventory']=r['products_cogs']*a['inventory_days']/365
        r['change_inventory']=r['inventory']-p['inventory']
        r['change_other_wc']=wc(r)-wc(p)
        r['cfo']=r['net_income']+r['da']-r['change_inventory']-r['change_other_wc']
        r['cfi']=-r['capex']
        opening_debt=p['debt_current']+p['debt_long']
        r['repayment']=min(a['repayment'],opening_debt)
        closing_debt=opening_debt-r['repayment']
        r['debt_current']=min(a['repayment'],closing_debt)
        r['debt_long']=closing_debt-r['debt_current']
        r['fcfe']=r['cfo']-r['capex']-r['repayment']
        r['dividends']=a['dividends']
        r['opening_cash']=p['cash']
        available=p['cash']+r['fcfe']-r['dividends']
        r['buybacks']=min(a['buybacks'],max(0.,available-a['cash_floor']))
        r['buyback_reduction']=a['buybacks']-r['buybacks']
        r['cff']=-r['repayment']-r['dividends']-r['buybacks']
        r['cash']=p['cash']+r['cfo']+r['cfi']+r['cff']
        r['equity']=p['equity']+r['net_income']-r['dividends']-r['buybacks']
        r['assets']=sum(r[k] for k in ASSETS)
        r['liabilities']=sum(r[k] for k in LIABILITIES)
        r['liabilities_equity']=r['liabilities']+r['equity']
        rows.append(r)
        p=r
    return rows


def valuation(rows,a=A):
    assert_balanced(rows,a)
    k,g=a['ke'],a['terminal_growth']
    if not k>g or k<=-1 or a['shares']<=0:
        raise ValueError('Require ke > terminal growth, ke > -1, positive shares')
    # Week 6: retain negative explicit cash flows, never floor them at zero.
    pv=sum(r['fcfe']/(1+k)**t for t,r in enumerate(rows,1))
    # At terminal: refinance maturities (net repayment 0) and replenish amortized assets.
    normal=rows[-1]['fcfe']+rows[-1]['repayment']-rows[-1]['other_amort']
    if rows[-1]['fcfe']<=0 or normal<=0:
        raise ValueError('Terminal value unresolved: nonpositive FCFE cannot support positive growing perpetuity')
    terminal=normal*(1+g)/(k-g)
    pvt=terminal/(1+k)**5
    return dict(pv_explicit=pv,normalized_fcfe=normal,terminal=terminal,pv_terminal=pvt,
                equity=pv+pvt,per_share=(pv+pvt)/a['shares'],terminal_share=pvt/(pv+pvt))


def table(title,rows,lines):
    print('\n'+title+' (USD millions)')
    print(f"{'Line':<42}"+''.join(f"{'FY'+str(r['year'])+'E':>14}" for r in rows))
    for label,key in lines:
        print(f'{label:<42}'+''.join(f'{r[key]:>14,.1f}' for r in rows))


def label(key):
    return {'cogs':'Cost of sales','sga':'SG&A','rd':'Research and development',
            'ppe':'PP&E, net','cfo':'Operating cash flow','cfi':'Investing cash flow',
            'cff':'Financing cash flow','fcfe':'FCFE before dividends / buybacks',
            'change_inventory':'Inventory increase (subtract)',
            'change_other_wc':'Other WC increase / (release)',
            'other_amort':'Other D&A addback','assets':'Total assets',
            'liabilities':'Total liabilities','liabilities_equity':'Total liabilities + equity',
            'other_current_liabilities':'Other current liabilities, excluding tax',
            'other_long_assets':'Other long-term assets, excluding DTA',
            'tax':'Income tax expense','net_other':'Net other income / (expense)',
            'equity':"Shareholders' equity"}.get(key,key.replace('_',' ').title())

