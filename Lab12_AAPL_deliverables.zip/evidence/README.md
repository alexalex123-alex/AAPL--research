# Existing evidence reused for Lab 12

Start with [the Lab 12 checkout](../Lab12_AAPL_checkout.md).

| Purpose | Files |
|---|---|
| Initial company selection and thesis | [Original Apple report](Apple_2026-09-03_report.md) |
| Historical statements and sources | [History and ratios](AAPL_Part1_history_and_ratios.md), [five-year statements](AAPL_three_statements_FY2021_FY2025.md) |
| Original own-company pro-forma | [Lab 10 explanation](Lab10_checkout.md), [engine](apple_proforma.py), [visible output](apple_proforma_output.txt) |
| Accounting safeguards | [verification code](verify_apple_proforma.py), [verification output](apple_verification_output.txt), [intentional failure output](apple_broken_cash_output.txt) |
| Current Services model | [engine](apple_services_proforma.py), [sensitivity runner](apple_services_sensitivity.py) |
| Current sensitivity evidence | [Lab 11 analysis](Lab11_services_stability_checkout.md), [visible output](Lab11_services_output.txt), [full results](Lab11_services_results.json) |
| Earlier FCFF and reverse DCF | [explanation](apple_dcf_reverse_dcf.md), [code](dcf.py), [saved output](week3_dcf_output.txt) |

These are unchanged copies of existing project evidence. Historical reports retain their original caveats and dates. The current Services model supersedes the earlier iPhone-margin sensitivity for this checkout. No partner model was supplied or reproduced.
