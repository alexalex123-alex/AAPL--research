"""Run Services growth and cost-of-equity sensitivities.
python apple_services_sensitivity.py --services-low 5 --services-base 10 --services-high 15
Rates on command line are percentages. Keep beside apple_services_proforma.py.
"""
import argparse
import copy
import json
from pathlib import Path
import apple_services_proforma as model


def run_case(name,inputs):
    a=copy.deepcopy(inputs)
    result=dict(name=name,inputs=a,status='valid')
    try:
        rows=model.project(a)
        model.assert_balanced(rows,a)
    except ValueError as e:
        result.update(status='invalid',reason=str(e),per_share=None)
        return result
    last=rows[-1]
    result.update(rows=rows,operating_income=last['operating_income'],fcfe=last['fcfe'],
        services_revenue=last['services_revenue'],services_share=last['services_share'],
        gross_margin=last['gross_margin'],per_share=None)
    try:
        result['valuation']=model.valuation(rows,a)
        result['per_share']=result['valuation']['per_share']
    except ValueError as e:
        result['valuation_reason']=str(e)
    result['checks']=[dict(year=r['year'],gap=model.gap(r),cash=r['cash'],
        cash_floor=a['cash_floor'],cash_ok=r['cash']>=a['cash_floor']-1e-6) for r in rows]
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for arg in ('services-low','services-base','services-high'):
        p.add_argument('--'+arg,type=float,required=True)
    args=p.parse_args()
    if not -100<args.services_low<args.services_base<args.services_high:
        p.error('Services rates must be ordered lower < base < higher, all above -100%')
    original=copy.deepcopy(model.A)
    base_inputs=dict(model.A,services_growth=args.services_base/100)
    cases=[run_case('Base',base_inputs),
        run_case('More stable: cost of equity 8%',dict(base_inputs,ke=.08)),
        run_case('Stability shock: cost of equity 12%',dict(base_inputs,ke=.12)),
        run_case(f'Services growth {args.services_low:g}%',dict(base_inputs,services_growth=args.services_low/100)),
        run_case(f'Services growth {args.services_high:g}%',dict(base_inputs,services_growth=args.services_high/100))]
    base=cases[0]
    if base['status']!='valid' or base['per_share'] is None:
        raise ValueError('Base cannot support this valuation comparison')
    for i,c in enumerate(cases):
        changed=[k for k,v in c['inputs'].items() if v!=base_inputs[k]]
        expected=[] if i==0 else ['ke'] if i in (1,2) else ['services_growth']
        if changed!=expected:raise AssertionError('More than one independent input changed')
        if c['status']=='valid':
            for k in ('operating_income','fcfe','per_share'):
                c['delta_'+k]=c[k]-base[k] if c[k] is not None else None
    for c in cases[1:3]:
        if c['rows']!=base['rows']:raise AssertionError('Discount-only shock changed statements')
    for c in cases[3:]:
        if c['status']!='valid':continue
        ds=c['services_revenue']-base['services_revenue']
        expected=ds*(base_inputs['services_margin']*(1-base_inputs['sga_gp'])-base_inputs['rd_sales'])
        if abs(c['delta_operating_income']-expected)>1e-6:raise AssertionError('Services EBIT bridge failed')
        if abs(c['rows'][-1]['inventory']-base['rows'][-1]['inventory'])>1e-6:
            raise AssertionError('Services-only shock changed Products inventory')
    restored=run_case('Restored base',base_inputs)
    if model.A!=original or restored['rows']!=base['rows'] or restored['per_share']!=base['per_share']:
        raise AssertionError('Base not restored exactly')
    spans={}
    for name,group in [('Stability',[cases[1],base,cases[2]]),('Services growth',[cases[3],base,cases[4]])]:
        spans[name]={}
        for key in ('operating_income','fcfe','per_share'):
            vals=[c.get(key) for c in group if c['status']=='valid' and c.get(key) is not None]
            spans[name][key]=max(vals)-min(vals) if len(vals)==3 else None
    path=Path(__file__).resolve().parent
    result=dict(cases=cases,spans=spans,restored_base=restored,checks_passed=True)
    (path/'Lab11_services_results.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print('SERVICES GROWTH AND STABILITY -- NEW SEGMENTED BASE')
    print('USD millions except value per share; FY2030 operating outputs; FCFE definition.')
    for c in cases:
        print('\n'+c['name'])
        print(f"Independent rates: Services {c['inputs']['services_growth']:.2%}; Products {c['inputs']['product_growth']:.2%}; cost of equity {c['inputs']['ke']:.2%}")
        if c['status']!='valid':
            print('INVALID:',c['reason']);continue
        value='UNAVAILABLE' if c['per_share'] is None else f"${c['per_share']:.2f}"
        print(f"FY2030 Services revenue {c['services_revenue']:,.1f}; Services mix {c['services_share']:.2%}; consolidated gross margin {c['gross_margin']:.2%}")
        print(f"Operating profit {c['operating_income']:,.1f}; FCFE {c['fcfe']:,.1f}; value/share {value}")
        print('Signed differences:',{k:c.get('delta_'+k) for k in ('operating_income','fcfe','per_share')})
        for r in c['checks']:
            g=0. if abs(r['gap'])<1e-6 else r['gap']
            print(f"FY{r['year']}: gap {g:.1f}; cash {r['cash']:,.1f}; cash floor passed {r['cash_ok']}")
    print('\nSPANS:',spans)
    print('PASS exact restored-base match; one input changed per run; independent Services EBIT bridge; product inventory unchanged in Services-only runs.')
    for title,keys in [('NEW BASE INCOME STATEMENT',('products_revenue','services_revenue','revenue','gross_profit','sga','rd','operating_income','net_other','tax','net_income')),
        ('NEW BASE BALANCE SHEET',model.ASSETS+('assets',)+model.LIABILITIES+('liabilities','equity','liabilities_equity')),
        ('NEW BASE CASH FLOWS',('net_income','depreciation','other_amort','change_inventory','change_other_wc','cfo','cfi','repayment','fcfe','dividends','buybacks','cff','cash'))]:
        model.table(title,base['rows'],[(model.label(k),k) for k in keys])


if __name__=='__main__':main()
