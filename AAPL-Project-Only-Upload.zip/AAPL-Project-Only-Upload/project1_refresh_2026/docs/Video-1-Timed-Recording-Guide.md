# Video1 - timed narration and exact screen guide

Rehearsal timing only; not timestamps from an existing recording. Target2:50, hard limit3:00. Read only the quoted narration. Keep this guide on another screen/phone. Record the documents, not this guide. The full Research-Evolution.pdf has four pages: page1 current Edition A candidate; page2 evolution table; pages3-4 current memo.

## 0:00-0:25 - Research-Evolution.pdf, page2

Show the heading and old-versus-new table. Keep the valuation-date and price rows visible.

"I am Alex Schwanke. My project asks whether a fund with no position should initiate Apple. I recommend buy. I changed the valuation date from October2025 to September14,2026 because the Siri announcement supporting my thesis occurred in2026. I refreshed the financial and market inputs together."

## 0:25-0:55 - Partner-Review-Record.pdf, page1

Show Actual feedback received. Scroll to Jess's limitation and explanation-back clarification if necessary; use the heading, not a presumed page number, because PDF pagination may differ.

"Jess Tran challenged my original zero point five seven percent FCFF growth assumption as too low. She also questioned whether Siri AI was overhyped, with a buzzword rather than real utility. Her feedback pushed me to examine what Siri actually contributes through upgrades, retention and Services. The recommendation remains mine."

## 0:55-1:15 - Partner-Review-Record.pdf, reciprocal NVIDIA review section

Scroll to Reciprocal review of Jess's NVIDIA analysis. Keep the AI-bubble scenario and beta-check paragraphs visible.

"I also reviewed Jess's NVIDIA analysis. I suggested testing an AI-bubble-burst scenario and manually checked beta. The record does not certify the whole WACC from that check. My feedback was a proposed stress test, not a claim that Jess already ran it."

## 1:15-1:55 - Alex-Growth-Exercise.md

Show the opening paragraph with prediction commit4173681, then the before/after output table and actual ratio. Open the Markdown in a readable editor/preview and enlarge the text before recording.

"For a separate test of my original model, I predicted that increasing annual FCFF growth from zero point five seven percent to one percent would raise valuation, perhaps by one and a half times. My prediction was committed before assistant execution. Value rose from ninety dollars and sixty-six cents to ninety-two dollars and thirty-three cents: only one point eight four percent. I had the direction right but overestimated the size because I had not done the exact math. I still recommend buy."

## 1:55-2:15 - Alex-Growth-Exercise.md, final paragraphs

Show your quoted post-run diagnosis and the disclosure separating your judgment from assistant execution.

"This test used the original historical DCF, not the current operating forecast. My prediction and personal diagnosis are recorded separately from the assistant's technical execution. I am not presenting it as an independently documented AI-off run."

## 2:15-2:50 - Research-Evolution.pdf, page2

Show Tested AI output and disposition near the bottom of page2. Finish with the evolution table visible.

"The source checks also caught a missing intangible-asset line that broke the refreshed balance sheet. The filing supplied the correction instead of a balancing plug. The current model derives FCFF from operating drivers. Its core values remain below price, so my buy judgment depends on demanding AI execution and persistence assumptions. AI accelerated the work; it does not own that judgment."

## Before recording

Open the three documents and practice switching tabs. Use Research-Evolution.pdf from Final-Assignment, not the shorter standalone evolution PDF, so page2 matches this guide. Timing includes screen switches; speak naturally and shorten pauses if necessary. Do not rush to force exact timestamps. After recording, correct the actual transcript and use observed timestamps. If showing Edition A or a receipt, describe actual submission status accurately; this narration makes no receipt claim.
