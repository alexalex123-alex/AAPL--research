# AAPL - Project1 only

Active valuation: September14,2026 close | Alex Schwanke | USD | Fund has no position | proposed3-5year horizon.

Student action INITIATE. Core FCFF DCF73-254/share versus333.08 close. Extended high operating/duration cases286-350 require durable growth and high returns. The initiation defense retains the downside asymmetry; no protected expected return is asserted.

## Deliverables

- [Decision memo](docs/decision-memo.pdf)
- [Research evolution and current Edition A candidate/Edition B](docs/research-evolution.pdf)
- [Validation and AI disclosures](docs/validation-and-ai-use.pdf)
- [Video links/transcript register](docs/VIDEO-LINKS.md) - student handles recordings/transcripts
- [Active application and detailed instructions](project1_refresh_2026/README.md)
- [Visible results](project1_refresh_2026/visible_output/index.html) - download/open locally
- [Machine-readable result](project1_refresh_2026/visible_output/results.json)
- [Project evidence, partner review and challenges](project1_refresh_2026/docs/)

## Run

From project1_refresh_2026, using Python3.10+ standard library:

```
python -m unittest discover -s . -p "test_*.py" -v
python run.py --serve --port 8766
```

Open http://127.0.0.1:8766. Windows users may use Start-AAPL.cmd. Included financial output is visible without rerunning. No API credentials are needed.

The sole historical engine at root, dcf.py, reproduces Alex's original FCFF changed-input exercise. It is not the active forecast. Its exact source hash and project-only pre-run record/commit metadata are preserved in docs/Original-Growth-Exercise-Provenance. No coursework labs or full-repository history bundles are included.

AI use remains disclosed. Alex reports videos complete and handles actual video links/corrected transcripts; those assets were not supplied to the assistant. Edition A first receipt, remote publication/access and exercise-protocol acceptance are not invented. Current research evolution includes an unchanged prepared candidate pending the actual received baseline.
