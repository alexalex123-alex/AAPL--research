"""Apply the Lab 07 calculator to Apple using sourced 2025-10-31 inputs.
Run: python lab08_peer_valuation.py
Requires the accompanying lab07_comps.py and dcf.py; standard library only.
"""
from lab07_comps import run
from dcf import calculate_dcf, GROWTH_RATES

TARGET = {'ticker': 'AAPL', 'price': '270.37', 'eps': '7.46'}
PEERS = [
    {'ticker': 'MSFT', 'price': '517.81', 'eps': '13.64', 'decision': 'qualify'},
    {'ticker': 'DELL', 'price': '162.01', 'eps': '6.38', 'decision': 'qualify'},
]

if __name__ == '__main__':
    run(TARGET, [p for p in PEERS if p['decision'] in ('use', 'qualify')],
        title='LAB 08 - APPLE PEER COMPARISON',
        basis='2025-10-31 closes / latest annual GAAP diluted EPS public by that date')
    print('\nRemove both peers:')
    run(TARGET, [], title='NO-PEER CHECK', basis='2025-10-31 comparison')
    print(f"\nSaved DCF reproduced: ${calculate_dcf(GROWTH_RATES)['value_per_share']:.4f}")
    print('DCF and peer methods are not averaged.')
