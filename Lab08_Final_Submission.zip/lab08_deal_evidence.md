# Lab 08 — Deal Evidence and Valuation Triangulation

**Target:** Apple Inc. (NASDAQ: AAPL). **Comparison date:** October 31, 2025, market close. **Valuation object:** USD per Apple common share.

**AI assistance:** Research, calculations and explanatory drafting were completed with AI. The initial policy, rejection of the criticism's decision weight, and initiate call reflect the student's instructions. No independent second AI session or classroom conversation is claimed.

## 1. Define the question

What would Apple be worth at annual reported P/E multiples of diversified technology businesses, and why might that differ from the saved DCF?

Apple sells devices and related services. FY2025 revenue was $416.161 billion, including $209.586 billion of iPhone sales and $109.158 billion of Services sales. Annual diluted EPS was positive at $7.46. Hardware demand, an installed customer base and services monetization matter to the comparison. [Apple FY2025 10-K][A], Item 1 Business; Item 7 net sales by category; consolidated income statements, p. 29.

The research question is whether a software/cloud business and a PC/infrastructure business provide useful qualified references for Apple's combination of hardware and services. An industry label alone does not establish equal growth, risk, capital requirements or earnings quality.

## 2. Initial policy — supplied by the student before research

> I want them to share that they are in tech, but i want to exclude if they are solely AI company, like microsoft is a peer but openai is not

This policy is retained without retrospective revision. Microsoft is the student's named candidate; Dell is the additional AI-suggested candidate. The lab separately requires listed operating companies and compatible financial inputs. AI involvement does not itself exclude a diversified company under the student's policy.

**Rejection evidence:** Solely AI-focused operations would fail the student's screen. Missing or nonpositive annual reported EPS would prevent using that company's P/E. An unbridgeable price/share/currency mismatch would also prevent calculation. Materially different business economics require qualification or exclusion even where the broad screen is met. These are analytical checks, not a claim that the student wrote a more detailed policy earlier.

## 3. Two candidate decisions

| Candidate | Decision | Business fit and important difference | Opened primary source and locator |
|---|---|---|---|
| Microsoft (NASDAQ: MSFT) | **Qualify** | Diversified technology business with software, subscriptions, cloud, Windows and gaming. Its recurring customer relationships provide some comparison with Apple's ecosystem. Enterprise software and cloud economics differ substantially from device-led consumer demand; its multiple is not automatically transferable. | [FY2025 annual report][M], Business → Operating Segments, especially Productivity and Business Processes, Intelligent Cloud and More Personal Computing. |
| Dell Technologies (NYSE: DELL, Class C) | **Qualify** | Hardware exposure provides a comparison with Apple's computer business. Dell's PC and enterprise infrastructure activities extend beyond AI. Enterprise infrastructure and commercial PCs differ from Apple's phone-led ecosystem and service economics. | [FY2025 results][D], Infrastructure Solutions Group; Client Solutions Group; Operating Segments Results. |

Both candidates remain in the calculation. Neither is excluded because of its resulting multiple. The student's OpenAI example is an initial policy exclusion, not a third researched listed candidate. No financial inputs are invented for it.

## 4. Inputs and evidence

All prices below are **October 31, 2025 closing prices in USD**, not dividend-adjusted total-return prices. EPS is the latest completed **annual GAAP reported diluted EPS public by that date**, not quarterly, forecast, adjusted or a rolling TTM figure.

| Company | Price | Annual diluted EPS | Fiscal year-end | Annual earnings publication | Earnings source and locator | Price source and locator |
|---|---:|---:|---|---|---|---|
| Apple | $270.37 | $7.46 | September 27, 2025 | October 30, 2025 | [Annual earnings release][AR]; [10-K][A], p. 29 income statements and p. 36 EPS note. 10-K filed October 31, 2025. | [Trading 212 AAPL][PA], Historical data → Oct 31, 2025 → Close |
| Microsoft | $517.81 | $13.64 | June 30, 2025 | July 30, 2025 | [FY25 Q4 release][MR], Fiscal Year 2025 Results and Income Statements → Twelve Months Ended June 30, 2025 → Diluted | [Trading 212 MSFT][PM], Historical data → Oct 31, 2025 → Close |
| Dell | $162.01 | $6.38 | January 31, 2025 | February 27, 2025 | [FY2025 release][D], Fourth Quarter and Full-Year Fiscal 2025 Financial Results → Fiscal Year Ended January 31, 2025 → Earnings per share—diluted | [Trading 212 DELL][PD], Historical data → Oct 31, 2025 → Close |

**Source check:** Sources above were opened by the assistant on September 14, 2026. Nasdaq's MSFT historical page returned unavailable data, so the opened broker history pages were used. Their Close fields agree with Yahoo search-index historical rows for the same date. The broker's other columns are not used. The student's own source review remains to be performed.

**Basis checks:** All three use USD common-share prices and USD annual diluted EPS; no FX or ADR conversion is used. Dell's adjusted annual EPS of $8.14 is deliberately kept separate from its reported $6.38. Fiscal periods differ: Dell's annual earnings are older than Apple's. This limits economic comparability even though all three comply with the same information cutoff. More recent quarterly results do not replace the required full-year denominator. [D]

## 5. Implement and explain the calculation

For each admitted peer:

`Peer P/E = peer closing price / peer annual reported diluted EPS`

`Apple implied price = peer P/E × Apple annual reported diluted EPS`

P/E expresses the dollars investors pay for one dollar of annual earnings. Applying that multiple to Apple's own EPS translates the reference into dollars per Apple share. The peer's share price alone cannot be transferred because its EPS and share count differ.

| Company supplying multiple | Calculation | P/E | Apple implied value |
|---|---|---:|---:|
| Microsoft | 517.81 / 13.64 | 37.962610x | $283.20 |
| Dell | 162.01 / 6.38 | 25.393417x | $189.43 |

**Qualified peer range: $189.43–$283.20 per Apple share.** This is the minimum and maximum of two references, not a confidence interval or an independently established fair-value range. Apple's own observed annual P/E is $270.37 / $7.46 = 36.242627x.

Run from the directory containing the supplied Python files:

```bash
python lab08_peer_valuation.py
python lab07_comps.py
python dcf.py
```

The terminal output is saved in `lab08_calculator_output.txt`. This implementation reuses the completed Lab 07 calculator, with optional title/date labels added so Apple is not mislabeled as Asbury. Running `lab07_comps.py` reproduces the frozen Asbury case. The Apple script prints both individual peer-removal checks and the no-peer case. Keep `lab07_comps.py` and `dcf.py` beside the Apple script; all use the standard library.

## 6. Validate one peer and changed-peer results

**Hand-check worked example:** $517.81 / $13.64 = 37.96260997x. Multiplying this by Apple's $7.46 gives $283.20107038, which rounds to $283.20. Back-check: 37.96260997 × $13.64 ≈ $517.81. This is the assistant's arithmetic demonstration, not a claim that the student performed it unaided.

**Prediction before the removal run:** Removing Microsoft, the higher-multiple peer, should remove the upper endpoint and leave Dell's lower reference. Removing Dell should leave Microsoft's upper reference. Neither sensitivity changes the actual admission decisions.

| Run | Calculator result | Interpretation |
|---|---|---|
| Both qualified peers | $189.43–$283.20 | Two economically different references produce a wide span. |
| Remove Microsoft | $189.43 | One Dell reference remains; no two-peer range exists. |
| Remove Dell | $283.20 | One Microsoft reference remains; no two-peer range exists. |
| Remove both | No estimate | There is no admitted multiple to apply. |

The large sensitivity is evidence that business selection matters, not grounds to discard an inconvenient outcome. The calculator also reproduced the saved DCF at $90.6619.

## 7. Compare with the saved Week 3 DCF

| Method | Your company's result and date | Main assumption or limitation |
|---|---|---|
| Week 3 DCF | **$90.66 per Apple share**, using October 31, 2025 as the comparison date inherited from the saved Apple report. The saved model supplies a point estimate, not a range. | Starting FCFF $95,622 million; annual five-year growth 0.57%; WACC 8.91%; terminal growth 2%; cash/investments $132,420 million; debt $98,657 million; diluted shares 15,004.697 million. Saved assumptions are reproduced, not independently re-established as market-calibrated on the date. |
| Peer P/E | **$189.43–$283.20 per Apple share**, October 31, 2025 | Two qualified technology peers; annual GAAP diluted EPS with differing fiscal year-ends. Transferability of their multiples is uncertain. |

The supporting saved model and write-up are included as `dcf.py` and `apple_dcf_reverse_dcf.md`. The DCF discounts company cash flows, adds net cash and divides equity value by diluted shares, so its final output is comparable in valuation object to the P/E per-share result. FCFF itself is not EPS, and enterprise value must not be compared directly with a share price.

The DCF assumes slow cash-flow growth and is sensitive to the forecast and discount rate; 71.44% of its enterprise value comes from discounted terminal value. P/E imports market expectations and peer-specific risks. A gap can therefore reflect conservative DCF assumptions, richer market pricing, imperfect peers, or a combination. This exercise cannot identify a single cause from the gap alone.

**Date correction:** The saved reverse DCF uses $326 as a target to solve for growth. That is not the verified October 31, 2025 price of $270.37. Its 33.70% implied growth result is therefore not the growth implied by the comparison-date price. The base DCF remains $90.66 because its calculation does not depend on that reverse target. The prior report's 2026 leadership update is excluded from this historical comparison.

## 8. Skeptical AI review and source check

**AI criticism:** The weakest assumption is that membership in technology makes the two market multiples transferable to Apple. Microsoft and Dell qualify under the initial screen, but their customer mix and sources of earnings differ. Also, do not call the saved DCF a range or treat $326 as the historical close. Do not average the methods to hide their disagreement.

**One question that could change the decision:** What operating evidence available by October 31, 2025 would justify Apple's cash-flow growth being materially above the saved 0.57% forecast, and would that evidence also justify applying Microsoft's multiple?

**Judgment: reject the criticism's weight as a reason to change my initiate call.** I do not dispute that the businesses differ or that a technology label alone is insufficient. I reject the recommendation to defer on that basis because Microsoft's software/services ecosystem provides a qualified comparison with Apple's services monetization, while Dell provides a hardware comparison. Both remain qualified; neither is removed to improve the result. [A][M][D]

**Source-checked reason:** Apple reported FY2025 Services revenue growth of 14% to $109.158 billion, compared with 6% total revenue growth. This supports investigating whether the saved 0.57% FCFF growth assumption is too conservative. Microsoft's operating-segment disclosures support a software and recurring-services comparison, although its enterprise/cloud mix differs. These observations support my interpretation; they do not prove equal earnings economics or a higher future FCFF growth rate. [A][M]

The factual corrections are retained: $270.37 is the comparison-date price, $326 is only the saved reverse-DCF target, and the saved DCF is a point estimate. Whether the entire DCF/peer gap reflects an overly conservative forecast remains **unresolved**. The original AI criticism did not claim that qualified peers are unusable, so I am rejecting its influence on my decision rather than attributing that claim to it.

## 9. Final call and conditional defense

**Final call: initiate**, retaining my prior call. Apple’s Services growth and Microsoft's qualified reference support my positive interpretation. Applying Microsoft's 37.962610x multiple to Apple's $7.46 EPS gives **$283.20**, about **4.75% above** the $270.37 comparison-date close. This is modest potential price upside under that specific comparison, not a guaranteed return or an established margin of safety. [A][M][PM][PA]

**Range I can defend:** $189.43–$283.20 as a qualified peer-implied range. I withhold a combined intrinsic-value range because the saved $90.66 DCF and the peer estimates have not been reconciled. The peer median is $236.32; it is a descriptive peer statistic, not an average of the DCF and P/E methods.

**Contrary evidence:** The Dell reference of $189.43 is about 29.93% below the observed price; the peer median is about 12.59% below it, and the DCF is about 66.47% below it. Retaining initiate therefore puts more confidence in future operating performance and the services comparison than the saved DCF supports. The arithmetic does not establish that Apple is a bargain. Dell remains in the range despite this unfavorable result.

**What would change my decision:** Sustained Services deceleration, weaker cash conversion, or evidence supporting the DCF's low FCFF growth assumption would lead me to reconsider initiate in favor of watch-defer or do not initiate. A dated revenue-to-FCFF forecast is the most useful next evidence because growth in sales does not automatically become growth in cash available to investors.

**Answer to the skeptical question:** Services growth supplies a reason to investigate a stronger forecast, and Microsoft's business disclosures supply a reason to retain a qualified services comparison. Neither alone validates transplanting its multiple or replacing 0.57% with a particular growth rate. I retain initiate as a conditional judgment while recognizing that this forecast gap remains unresolved. No new unsupported DCF range is invented.

## 10. Checkout

Submit the report and calculator links, with the folder link for required supporting Python files:

- [Markdown report](https://github.com/alexalex123-alex/AAPL--research/blob/main/Lab08/lab08_deal_evidence.md)
- [Apple calculator](https://github.com/alexalex123-alex/AAPL--research/blob/main/Lab08/lab08_peer_valuation.py)
- [All Lab 08 files and dependencies](https://github.com/alexalex123-alex/AAPL--research/tree/main/Lab08)

Files include this report, `lab08_peer_valuation.py`, `lab07_comps.py`, `dcf.py`, captured Apple and Asbury outputs, and the saved DCF write-up. The calculator can be rerun without downloads or external packages.

**Process record:** The student supplied the initial policy and explicitly retained initiate and rejected the AI criticism's judgment. Sources were opened and calculations checked by the assistant. A second independent AI response and human partner question were not supplied; no completion of those classroom steps or independent student source review is claimed. The skeptical question answered above is the actual AI question from this conversation.

## Source links

[A]: https://www.sec.gov/Archives/edgar/data/320193/000032019325000079/aapl-20250927.htm
[AR]: https://www.apple.com/newsroom/2025/10/apple-reports-fourth-quarter-results/
[M]: https://www.microsoft.com/investor/reports/ar25/index.html
[MR]: https://www.microsoft.com/en-us/Investor/earnings/FY-2025-Q4/press-release-webcast
[D]: https://www.dell.com/en-us/dt/corporate/newsroom/announcements/detailpage.press-releases~usa~2025~02~dell-technologies-delivers-fourth-quarter-and-full-year-fiscal-2025-financial-results.htm
[PA]: https://www.trading212.com/trading-instruments/invest/AAPL.US
[PM]: https://www.trading212.com/trading-instruments/invest/MSFT.US
[PD]: https://www.trading212.com/trading-instruments/invest/DELL.US
