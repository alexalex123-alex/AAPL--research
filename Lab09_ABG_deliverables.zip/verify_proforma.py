"""Reproduce the lab checkpoints and exercise the financing safeguards."""
from proforma import ASSUMPTIONS, OPENING, project, value_equity, assert_balanced


def expect_failure(rows, assumptions, expected):
    try:
        value_equity(rows, assumptions)
    except ValueError as error:
        if expected not in str(error):
            raise AssertionError(str(error)) from error
        print(f'PASS expected refusal: {error}')
    else:
        raise AssertionError('Invalid model reached valuation')


rows = project()
expected = {
    'revenue': ('18323.0', '19678.3'),
    'operating_income': ('844.2', '971.4'),
    'net_income': ('413.6', '527.5'),
    'fcfe': ('211.4', '342.3'),
    'cash': ('101.8', '719.8'),
}
for key, pair in expected.items():
    actual = tuple(f'{r[key]:.1f}' for r in (rows[0], rows[-1]))
    if actual != pair:
        raise AssertionError(f'{key}: {actual} != {pair}')
assert_balanced(rows)
v = value_equity(rows)
if f"{v['per_share']:.2f}" != '291.75':
    raise AssertionError('Wrong value per share')
print('PASS all supplied FY2026E / FY2030E checkpoints and $291.75 per share')
print('PASS all five balance sheets and minimum-cash checks')
broken = [r.copy() for r in rows]
broken[0]['cash'] = OPENING['cash']
expect_failure(broken, ASSUMPTIONS, 'FY2026E: assets - liabilities - equity gap -61.4')

# Larger buybacks force borrowing in the first year and repayment subsequently.
stress = dict(ASSUMPTIONS, buyback=300.)
stress_rows = project(assumptions=stress)
assert_balanced(stress_rows, stress)
if not stress_rows[0]['change_revolver'] > 0:
    raise AssertionError('Expected a revolver draw')
if not any(r['change_revolver'] < 0 for r in stress_rows[1:]):
    raise AssertionError('Expected revolver repayment')
print('PASS revolver draw and subsequent repayment; stressed statements balance')
constrained = dict(stress, revolver_limit=1.)
expect_failure(project(assumptions=constrained), constrained, 'FY2026E: cash below minimum')
print('PASS verification complete')
