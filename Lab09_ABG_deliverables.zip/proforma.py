"""Lab 09 ABG: USD millions except per-share amounts. Standard library only.

Run: python proforma.py
Break the balance sheet: python proforma.py --break-2026-cash
Inputs reproduce the supplied teaching case, not independently verified filings.
"""
import argparse
import math

ASSUMPTIONS = dict(growth=.018, gross_margin=.1705,
    sga_ratios=(.665, .655, .645, .645, .645), depreciation_ratio=82.4/3070.4,
    impairment=120., capex=250., tax_rate=.255,
    inventory_days=2135.8/(17999.-3071.7)*365,
    floor_plan_ratio=2027./2135.8, other_wc_ratio=.008,
    minimum_cash=25., revolver_limit=850., revolver_rate=.06,
    repayment=150., buyback=150., floor_plan_rate=.0467, debt_rate=.0544,
    cost_of_equity=.10, terminal_growth=.025, shares=17.951349)
OPENING = dict(revenue=17999., inventory=2135.8, ppe=3070.4,
    other_assets=6371.6, cash=40.4, floor_plan=2027., debt=3572.,
    other_liabilities=2127.5, equity=3891.7, revolver=0.)


def balance_gap(row):
    return (row['cash'] + row['inventory'] + row['ppe'] + row['other_assets']
            - row['floor_plan'] - row['debt'] - row['revolver']
            - row['other_liabilities'] - row['equity'])


def assert_balanced(rows, assumptions=ASSUMPTIONS):
    """Refuse valuation on an unbalanced or infeasible year; never use assert."""
    for row in rows:
        year = f"FY{row['year']}E"
        gap = balance_gap(row)
        if not all(math.isfinite(v) for v in row.values()):
            raise ValueError(f'{year}: non-finite value; gap {gap:+.1f}')
        if abs(gap) > 1e-7:
            raise ValueError(f'{year}: assets - liabilities - equity gap {gap:+.1f}')
        if row['cash'] < assumptions['minimum_cash'] - 1e-7:
            raise ValueError(f"{year}: cash below minimum; gap {row['cash'] - assumptions['minimum_cash']:+.1f}")
        if not -1e-7 <= row['revolver'] <= assumptions['revolver_limit'] + 1e-7:
            raise ValueError(f'{year}: revolver outside permitted range; balance gap {gap:+.1f}')


def project(opening=OPENING, assumptions=ASSUMPTIONS):
    a = assumptions
    p = opening.copy()
    if abs(balance_gap(p)) > 1e-7:
        raise ValueError('Opening balance sheet does not balance')
    if len(a['sga_ratios']) != 5:
        raise ValueError('Supply five SG&A ratios')
    rows = []
    for i, year in enumerate(range(2026, 2031)):
        r = dict(year=year)
        r['revenue'] = p['revenue'] * (1 + a['growth'])
        r['gross_profit'] = r['revenue'] * a['gross_margin']
        r['cost_of_sales'] = r['revenue'] - r['gross_profit']
        r['sga'] = r['gross_profit'] * a['sga_ratios'][i]
        r['depreciation'] = p['ppe'] * a['depreciation_ratio']
        r['impairment'] = a['impairment']
        r['operating_income'] = r['gross_profit'] - r['sga'] - r['depreciation'] - r['impairment']
        r['interest'] = p['floor_plan'] * a['floor_plan_rate'] + p['debt'] * a['debt_rate'] + p['revolver'] * a['revolver_rate']
        r['pretax'] = r['operating_income'] - r['interest']
        r['tax'] = max(0., r['pretax']) * a['tax_rate']
        r['net_income'] = r['pretax'] - r['tax']
        r['inventory'] = r['cost_of_sales'] * a['inventory_days'] / 365
        r['floor_plan'] = r['inventory'] * a['floor_plan_ratio']
        r['capex'] = a['capex']
        r['ppe'] = p['ppe'] + r['capex'] - r['depreciation']
        r['change_other_wc'] = a['other_wc_ratio'] * (r['revenue'] - p['revenue'])
        r['other_assets'] = p['other_assets'] + r['change_other_wc'] - r['impairment']
        r['repayment'] = a['repayment']
        if r['repayment'] > p['debt']:
            raise ValueError(f'FY{year}E: repayment exceeds opening term debt')
        r['debt'] = p['debt'] - r['repayment']
        r['other_liabilities'] = p['other_liabilities']
        r['buyback'] = a['buyback']
        r['equity'] = p['equity'] + r['net_income'] - r['buyback']
        r['change_inventory'] = r['inventory'] - p['inventory']
        r['change_floor_plan'] = r['floor_plan'] - p['floor_plan']
        # Course convention: inventory financing belongs inside operating cash flow.
        r['cfo'] = r['net_income'] + r['depreciation'] + r['impairment'] - r['change_inventory'] - r['change_other_wc'] + r['change_floor_plan']
        r['cfi'] = -r['capex']
        r['fcfe'] = r['cfo'] - r['capex'] - r['repayment']
        before_revolver = p['cash'] + r['fcfe'] - r['buyback']
        if before_revolver < a['minimum_cash']:
            r['change_revolver'] = min(a['minimum_cash'] - before_revolver, max(0., a['revolver_limit'] - p['revolver']))
        else:
            r['change_revolver'] = -min(p['revolver'], before_revolver - a['minimum_cash'])
        r['revolver'] = p['revolver'] + r['change_revolver']
        r['cff'] = -r['repayment'] - r['buyback'] + r['change_revolver']
        r['change_cash'] = r['cfo'] + r['cfi'] + r['cff']
        r['opening_cash'] = p['cash']
        r['cash'] = before_revolver + r['change_revolver']
        rows.append(r)
        p = r
    return rows


def value_equity(rows, assumptions=ASSUMPTIONS):
    assert_balanced(rows, assumptions)
    a = assumptions
    k, g = a['cost_of_equity'], a['terminal_growth']
    if not k > g or k <= -1 or a['shares'] <= 0:
        raise ValueError('Require cost of equity > terminal growth, k > -1, shares > 0')
    pv_fcfe = sum(r['fcfe'] / (1+k)**i for i, r in enumerate(rows, 1))
    terminal = (rows[-1]['fcfe'] + rows[-1]['repayment']) * (1+g) / (k-g)
    pv_terminal = terminal / (1+k)**5
    equity = pv_fcfe + pv_terminal
    return dict(pv_fcfe=pv_fcfe, terminal=terminal, pv_terminal=pv_terminal,
                equity=equity, terminal_share=pv_terminal/equity,
                per_share=equity/a['shares'])


def table(title, rows, lines):
    print('\n' + title + ' (USD millions)')
    print(f"{'Line':<34}" + ''.join(f"{'FY'+str(r['year'])+'E':>13}" for r in rows))
    for label, key in lines:
        print(f'{label:<34}' + ''.join(f'{r[key]:>13,.1f}' for r in rows))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--break-2026-cash', action='store_true')
    args = parser.parse_args()
    rows = project()
    if args.break_2026_cash:
        rows[0]['cash'] = OPENING['cash']
    table('INCOME STATEMENT', rows, [(label, key) for label, key in [
        ('Revenue','revenue'),('Cost of sales','cost_of_sales'),('Gross profit','gross_profit'),
        ('SG&A','sga'),('Depreciation','depreciation'),('Impairment','impairment'),
        ('Operating income','operating_income'),('Interest','interest'),('Pretax income','pretax'),
        ('Tax','tax'),('Net income','net_income')]])
    for r in rows:
        r['assets'] = r['cash'] + r['inventory'] + r['ppe'] + r['other_assets']
        r['liabilities'] = r['floor_plan'] + r['debt'] + r['revolver'] + r['other_liabilities']
        r['liabilities_equity'] = r['liabilities'] + r['equity']
    table('BALANCE SHEET', rows, [('Cash','cash'),('Inventory','inventory'),('PP&E','ppe'),
        ('Other assets','other_assets'),('Total assets','assets'),('Floor plan','floor_plan'),
        ('Term debt','debt'),('Revolver','revolver'),('Other liabilities','other_liabilities'),
        ('Total liabilities','liabilities'),('Equity','equity'),('Liabilities + equity','liabilities_equity')])
    table('CASH FLOW STATEMENT', rows, [('Net income','net_income'),('Add depreciation','depreciation'),
        ('Add impairment','impairment'),('Inventory increase (subtract)','change_inventory'),
        ('Other WC increase (subtract)','change_other_wc'),('Floor plan increase (add)','change_floor_plan'),
        ('Operating cash flow','cfo'),('Investing cash flow (-capex)','cfi'),('Debt repayment (subtract)','repayment'),
        ('FCFE before buybacks/revolver','fcfe'),('Buybacks (subtract)','buyback'),
        ('Revolver draw / (repayment)','change_revolver'),('Financing cash flow','cff'),
        ('Change in cash','change_cash'),('Opening cash','opening_cash'),('Closing cash','cash')])
    print('\nCHECKS')
    for r in rows:
        gap = balance_gap(r)
        if abs(gap) < 1e-7:
            gap = 0.
        print(f"FY{r['year']}E: assets - liabilities - equity = {gap:.1f}; cash >= 25: {r['cash'] >= 25 - 1e-7}")
    v = value_equity(rows)  # Calls assert_balanced BEFORE doing valuation.
    print('\nVALUATION (USD millions except per share)')
    print(f"PV of five FCFE: {v['pv_fcfe']:,.2f}")
    print(f"Terminal value at FY2030E: {v['terminal']:,.2f}")
    print(f"PV of terminal value: {v['pv_terminal']:,.2f}")
    print(f"Equity value: {v['equity']:,.2f}")
    print(f"Share of value after 2030: {v['terminal_share']:.2%}")
    print(f"Value per share: ${v['per_share']:.2f}")


if __name__ == '__main__':
    main()
