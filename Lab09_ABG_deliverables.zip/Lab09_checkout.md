# Lab 09 — ABG pro-forma engine and known-answer checkout

The five-year ABG teaching-case model produces equity value of **$5,237.34 million**, or **$291.75 per share**. The present value of cash flows after 2030 supplies **79.76%** of equity value. All five balance sheets balance, and cash remains above the $25 million minimum.

## Files and reproduction

- `proforma.py`: single-file, standard-library engine; prints all three statements, checks, and valuation.
- `proforma_output.txt`: captured normal run, with years across and one decimal for statements.
- `verify_proforma.py`: known-answer comparison, deliberate cash error, revolver draw/repayment, and insufficient-capacity checks.
- `verification_output.txt`: captured verification results.
- `broken_cash_output.txt`: captured intentional failure; no valuation is printed.
- `week3_dcf_output.txt`: successful run of the existing Apple `dcf.py` in the course folder.

Run from the folder containing these files:

```bash
python proforma.py
python verify_proforma.py
python proforma.py --break-2026-cash
```

The final command intentionally exits with an error. Run the first command again for the intact model; the demonstration does not edit the saved assumptions or code.

## D — the question

> What are five years of a company's statements worth, built from assumptions you can defend, and how do you know the statements are right?

Under the supplied ABG assumptions, equity is worth $5.237 billion. This is the present value of five forecast FCFE amounts plus a terminal value, rather than simply the sum of earnings. The engine computes the statements in the prescribed order, reconciles assets with liabilities and equity, enforces minimum cash and revolver capacity, and matches the instructor's known answer. These checks establish internal consistency and reproduction of the case; they do not establish that the forecasts will occur.

## R — assumptions and opening balances

All money is USD millions unless stated otherwise. Labels below follow the assignment; historical inputs and the share-count filing reference are supplied case inputs, not independently verified research.

| Assumption | Value | Assignment label |
|---|---|---|
| Organic revenue growth | 1.8% annually | Judgment |
| Gross margin | 17.05% | Judgment |
| SG&A / gross profit, 2026–2030 | 66.5%, 65.5%, 64.5%, 64.5%, 64.5% | Judgment |
| Depreciation / opening PP&E | 82.4 / 3,070.4; retain full precision | History |
| Annual noncash impairment | 120 | Judgment |
| Annual capital spending | 250 | Guidance |
| Tax rate | 25.5%; applied only to positive pretax income | Judgment |
| Inventory days | 2,135.8 / (17,999.0 − 3,071.7) × 365 | History |
| Floor plan / inventory | 2,027.0 / 2,135.8 | History |
| Other working-capital investment | 0.8% × annual revenue change | Judgment |
| Minimum cash | 25 | History |
| Revolver limit / rate | 850 / 6% | Judgment / judgment |
| Annual term-debt repayment / buyback | 150 / 150 | Judgment |
| Floor-plan / term-debt interest rates | 4.67% / 5.44%, on opening balances | History |
| Cost of equity / terminal growth | 10% / 2.5% | Judgment |
| Shares | 17.951349 million; assigned reference: June 30, 2026 10-Q | Fact, as labeled in assignment |

FY2025 opening revenue is 17,999.0. Opening balances are cash 40.4, inventory 2,135.8, PP&E 3,070.4, other assets 6,371.6, floor plan 2,027.0, term debt 3,572.0, other liabilities 2,127.5, and equity 3,891.7. Opening revolver is assumed zero. Assets and liabilities plus equity both equal 11,618.2.

### The three operating judgments

1. **Revenue growth of 1.8%:** a modest organic-growth path drives sales, inventory, and related financing needs. It is a scenario assumption, not a fact established by the engine.
2. **Gross margin of 17.05%:** determines how much sales revenue remains to cover overhead, depreciation, impairment, and financing. Small changes matter because revenue is large.
3. **SG&A / gross profit falling from 66.5% to 64.5%:** assumes overhead consumes a smaller share of gross profit by 2028, then stays at that level. This operating improvement helps earnings and FCFE grow faster than revenue.

These are the three operating judgments highlighted for discussion. The discount rate and terminal growth are also important valuation judgments, especially with nearly 80% of value beyond the explicit forecast. Defending the operating assumptions beyond the classroom case would require evidence on sales, margins, and achievable cost control; the supplied numbers alone do not provide that evidence.

## I — how the engine works

Each year proceeds from revenue through net income; then inventory, floor-plan financing, PP&E, other assets, term debt, liabilities, and equity; then cash flow and finally cash. Interest uses opening balances, avoiding a circular calculation with current-year revolver draws. Impairment reduces income and other assets and is added back in cash flow because it is noncash. Depreciation reduces income and PP&E and is also added back. Other working-capital investment is separated from impairment when calculating changes in other assets.

FCFE equals net income + depreciation + impairment − capex − inventory increase − other working-capital investment + floor-plan increase − term-debt repayment. Buybacks reduce cash and equity after FCFE. A revolver covers cash shortfalls up to its limit; cash above the minimum first repays an outstanding revolver. Insufficient financing capacity causes a check failure and blocks valuation.

The statement presentation follows the lab's convention of including floor-plan changes in operating cash flow. It is a simplified teaching model. It keeps the supplied share count fixed despite buybacks and values the specified FCFE stream without adding opening cash or subtracting debt again.

## V — known-answer proof

| Line | FY2026E | FY2030E | Result |
|---|---:|---:|---|
| Revenue | 18,323.0 | 19,678.3 | Match |
| Operating income | 844.2 | 971.4 | Match |
| Net income | 413.6 | 527.5 | Match |
| FCFE | 211.4 | 342.3 | Match |
| Year-end cash | 101.8 | 719.8 | Match |
| Assets − liabilities − equity | 0.0 | 0.0 | Match |

Calculations retain full precision; rounding is only for display. The valuation uses:

`Equity = Σ[FCFE(t) / 1.10^t] + [(FCFE(2030) + repayment(2030)) × 1.025 / (0.10 − 0.025)] / 1.10^5`

| Component | USD millions unless stated |
|---|---:|
| PV of 2026–2030 FCFE | 1,059.87 |
| Terminal value at end of 2030 | 6,727.85 |
| PV of terminal value | 4,177.46 |
| Equity value | 5,237.34 |
| Value after 2030 / equity value | 79.76% |
| Equity value / 17.951349 million shares | $291.75 |

The $150 million repayment is added back for terminal cash flow because the instructed terminal method does not continue that fixed annual repayment forever. This is a terminal-model assumption, not a claim that all debt has been repaid by 2030. Independently rounded components can differ from the rounded total by $0.01 million.

### Swap-and-break evidence

Setting FY2026E cash to 40.4 instead of its calculated balance makes the engine refuse valuation with:

```text
ValueError: FY2026E: assets - liabilities - equity gap -61.4
```

The verification script also confirms that a $300 million annual buyback scenario draws the revolver and later repays it while keeping the balance sheets balanced. Reducing capacity to $1 million makes minimum cash infeasible and correctly blocks valuation.

The partner discussion is complete, as confirmed by the student. The software checks above were run locally; an actual exchange and execution of a partner's file and video viewing are not independently verified here.

## Floor plan — learn on your own

**What is it?** In this case, floor-plan financing is inventory borrowing from manufacturers' finance arms and banks. It finances vehicles held for sale.

**How does it work in this model?** Inventory follows cost of sales and the historical days ratio. Floor-plan balances follow inventory using the historical financing ratio. Interest uses the opening loan balance. The annual increase in loans is a source of cash inside the course's FCFE calculation, offsetting much of the inventory investment.

**Why can removing it create a large cash deficit?** A dealer still has to pay for inventory when inventory financing is unavailable. Removing existing financing as well as future financing can therefore create a major cash requirement. However, simply deleting a balance-sheet liability without recording its repayment is not a valid cash-flow scenario. Removing only the annual floor-plan increases in this pasted case removes approximately $189.5 million of cumulative funding over five years before interest changes, so it cannot by itself explain the video's roughly negative $1.1 billion figure. The video or its scenario details were not present in the inspected folder. That exact number should be checked against the video's starting balances, repayment treatment, and other assumptions rather than claimed as reproduced here.

## Reflection

**Why is cash computed last?** Cash is the result of operating, investing, and financing flows. Revenue and margins determine income; investment and financing policies determine where the cash goes. Computing cash last lets the independently calculated cash flow reconcile the balance sheet. Using cash as an arbitrary balancing plug could hide missing flows.

**What does −61.4 tell us before opening a cell?** Assets are $61.4 million below liabilities plus equity. In this deliberate test, that equals the missing first-year increase in cash: 101.8 − 40.4 = 61.4. The negative sign shows assets are understated relative to the funding side. In an unfamiliar model, the gap identifies the discrepancy's direction and size, but would not by itself prove which account is wrong.

## Course-folder context and checkout status

The existing `aschwank/dcf.py` and `apple_dcf_reverse_dcf.md` are prior Apple FCFF work. Running that script reproduced a base value of $90.6619 per share and reverse-DCF growth of about 33.70% at the supplied $326 target. Lab 09 specifies ABG and FCFE, so the Apple assumptions are not mixed into this engine. Applying the engine to Apple belongs to the Thursday preview, not this checkout.

Source of the ABG inputs, formulas, checkpoints, and learning prompts: the attached “Lab 09 — Pro-Forma Build: the Engine and the Known Answer.” No ABG video or additional ABG source files appeared in the inspected course folder.

The deliverables are organized together in the repository's `Lab09_ABG` folder. Submit the GitHub links to this checkout and `proforma.py`; the captured output and verification files provide supporting evidence.
