"""Behavioral checks for Lab 10. Run: python verify_apple_proforma.py"""
from apple_proforma import A, OPENING, project, valuation, assert_balanced, gap


def refuse(rows,a,text):
    try:
        valuation(rows,a)
    except ValueError as e:
        if text not in str(e):
            raise AssertionError(str(e)) from e
        print('PASS expected refusal:',e)
    else:
        raise AssertionError('Broken model reached valuation')


rows=project()
assert_balanced(rows)
v=valuation(rows)
if abs(gap(OPENING))>1e-6:
    raise AssertionError('Opening balances fail')
for r in rows:
    if abs(r['fcfe']-r['cfo']-r['cfi']+r['repayment'])>1e-6:
        raise AssertionError('FCFE bridge failed')
    if abs(r['operating_income']-(r['gross_profit']-r['sga']-r['rd']))>1e-6:
        raise AssertionError('R&D / D&A treatment failed')
print('PASS opening balance sheet and five annual balance/cash-flow checks')
print('PASS R&D deducted once; D&A not deducted twice; FCFE bridge')
print(f"Base value per share: ${v['per_share']:.2f}")
broken=[r.copy() for r in rows]
broken[0]['cash']=OPENING['cash']
refuse(broken,A,'FY2026E: assets - liabilities - equity gap -1,010.0')
stress=dict(A,buybacks=200000.)
sr=project(stress)
assert_balanced(sr,stress)
if not sr[0]['buyback_reduction']>0 or abs(sr[0]['cash']-stress['cash_floor'])>1e-6:
    raise AssertionError('Buyback capacity safeguard failed')
print('PASS oversized buybacks reduced to preserve cash floor')
bad=dict(A,dividends=300000.)
refuse(project(bad),bad,'cash-floor gap')
decline=dict(A,growth=-.1)
if valuation(project(decline),decline)['per_share']>=v['per_share']:
    raise AssertionError('Lower growth did not reduce value')
print('PASS growth sensitivity: lower growth reduces model value')
print('PASS all checks completed')
