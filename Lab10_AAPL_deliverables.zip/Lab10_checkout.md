# Lab 10 — Apple (AAPL): your company through the engine

The five-year model produces **$112.54 per share**, with equity value **$1,662,577.78 million**. Every forecast year balances and cash remains above the **25,000 million** floor. This is a FY2025-base classroom FCFE valuation using the assumptions below, not a current-date investment recommendation.

## Files and reproduction

- `apple_proforma.py`: self-contained Python engine, standard library only.
- `apple_proforma_output.txt`: all five years of income statements, balance sheets, cash flows, checks and valuation.
- `verify_apple_proforma.py` and `apple_verification_output.txt`: safeguards and refusal tests.
- `apple_broken_cash_output.txt`: intentional failed run, with valuation blocked.
- `AAPL_Part1_history_and_ratios.md`: sourced three-year grid, ratios, Yahoo capex comparison and confirmed personal checks.
- `Lab10_ABG_prerequisite_output.txt`: original ABG engine rerun; **$291.75** reproduced. The original `proforma.py` remains unchanged.

```bash
python apple_proforma.py
python verify_apple_proforma.py
python apple_proforma.py --break-2026-cash
```

The third command intentionally returns an error. The switch does not modify the saved model; rerun without it to restore the normal result.

## D — question and personalization

**What are five years of your company's statements worth, built from assumptions you can defend?**

Company: **Apple Inc. (AAPL)**. The company-specific line is **R&D**, which is a substantial operating cost separate from SG&A and must be deducted explicitly. Apple has **no modeled floor-plan financing**. The engine also includes dividends, commercial paper, marketable securities and separately identified tax balances.

Apple's historical gross margin and operating expenses already include D&A. The engine calculates operating income as gross profit minus SG&A minus R&D, then adds D&A back only in the cash-flow calculation while reducing the related asset balances. It does not apply the ABG instruction to deduct D&A from already inclusive expenses a second time.

## R — history and assumptions

The companion [history and ratios](AAPL_Part1_history_and_ratios.md) identifies the filing for every history item. The student confirmed personally checking **FY2023 revenue of 383,285** and **FY2024 net income of 93,736**. The Yahoo Finance annual Capital Expenditure field matches the filings for all three years after conversion from thousands to millions.

The reasons below are working first-person explanations for review and ownership by the student. Historical amounts continued into future years are forecast judgments unless the row specifically identifies a historical calibration. No forward management guidance has been established for these inputs.

| Value | Label (history, guidance, judgment) | Reason |
|---|---|---|
| Opening revenue: **416,161**; opening balance sheet: **FY2025 reported balances** | History | Start with the most recent completed fiscal year. Income statement p. 29 and balance sheet p. 31 provide the starting values; retain Apple's full asset, liability and equity accounts. |
| Revenue growth: **5.0% annually**, FY2026–FY2030; organic growth: **unresolved / not separately disclosed** | Judgment | I use moderate total-company growth below FY2025's 6.43%, rather than assume the latest year's pace continues. It is above FY2024's 2.02%, so this case assumes continued expansion. I do not call it same-store or organic growth because the filings do not supply those measures. |
| Gross margin: **46.9% annually** | Judgment | I hold profitability near FY2025's 46.91%. Margins improved across the three years, but I do not assume that improvement continues indefinitely. |
| SG&A / gross profit: **14.1% annually** | Judgment | I keep overhead near FY2025's 14.14% of gross profit. This permits SG&A to grow with the business without assuming further cost-efficiency gains. |
| R&D / revenue: **8.3% annually**, separately from SG&A | Judgment | FY2025 R&D was 34,550, or about 8.30% of revenue. I keep that investment intensity because new products and services require ongoing research spending. Omitting R&D would overstate Apple's operating income. |
| PP&E depreciation / opening net PP&E: **approximately 16.05% annually** | History | Calibrated from FY2025 PP&E depreciation of approximately 8,000 divided by closing net PP&E of 49,834, using the course's historical-ratio convention. Apply this calibrated rate to opening PP&E in each forecast year. Note 5 reports depreciation rounded to billions, so this is not an exact accounting rate. |
| Other depreciation and amortization: **approximately 3,698 annually**, separately modeled | Judgment | FY2025 total D&A of 11,698 exceeds PP&E depreciation of approximately 8,000 by approximately 3,698. I hold that residual flat as a simplified noncash-expense assumption. It must be matched to the relevant non-PP&E asset roll-forward and must not be deducted from earnings twice. |
| Incremental impairment charge: **0 annually** | Judgment | I do not invent a recurring future impairment without a specific identified event or disclosed plan. This means no additional modeled impairment, rather than a claim that Apple can never record one. |
| Capital spending: **12,715 annually** | Judgment | I hold cash PP&E investment at FY2025's level because no verified multi-year capital-spending guidance has been established here. The filing's cash outflow matches Yahoo Finance's Capital Expenditure field after converting units. This is a baseline, not management guidance. |
| Effective tax rate: **16.0% of positive pretax income** | Judgment | I use a rate near FY2025's 15.61% and above FY2023's 14.72%. FY2024's 24.09% included a large one-time State Aid tax charge, so I do not treat that year as the recurring rate. |
| Inventory days: **9.45 days** | History | FY2025 inventory of 5,718 / cost of sales of 220,960 × 365 gives 9.45 days. Use closing inventory and a 365-day convention to match the lab. |
| Inventory floor-plan financing: **none; balance and related interest = 0** | Judgment | I include no separate inventory-loan facility because the reviewed Apple statements do not identify an ABG-style floor-plan line. Apple's commercial paper and term debt remain separate financing accounts. This does not mean Apple has no debt or supplier financing. |
| Other operating working capital: **hold FY2025 account-to-revenue ratios constant**, excluding inventory, cash, investments, debt and separately modeled taxes | Judgment | I let operating receivables, supplier payables and other operating balances move with sales. I use Apple's own account relationships instead of copying ABG's 0.8% assumption. Inventory is already modeled through days, so I do not count it again. Tax-related balances need their own treatment because of the State Aid settlement. |
| Net other income / (expense): **(321) annually**; no separate additional interest deduction in this simplified case | Judgment | I hold the FY2025 reported net other expense flat as a transparent baseline. It already includes the net effect of nonoperating income and expenses, so adding a separate interest expense on top would double count part of financing cost. A detailed debt-and-investment schedule would replace this row. |
| Term-debt repayments: **10,932 annually**, capped at opening term debt; new commercial-paper issuance: **0 net** | Judgment | I use FY2025 cash term-debt repayments as a simple annual baseline, not as Apple's contractual maturity schedule. I assume no net increase in commercial paper. A maturity-based forecast would replace the flat repayment amount. |
| Share repurchases: **90,711 annually**, reduced if necessary to preserve minimum cash | Judgment | I start with FY2025 cash repurchases but treat them as discretionary. I would reduce buybacks before assume borrowing from an unverified facility. |
| Dividends: **15,421 annually** | Judgment | I keep total cash dividends at FY2025's level as a simple baseline. Dividends are a separate cash and equity reduction from repurchases and must be included in an Apple model. |
| Minimum cash: **25,000**; modeled incremental revolver capacity: **0** | Judgment | I keep a substantial cash buffer below FY2025's 35,934 cash balance. I do not assume the ABG revolver is available to Apple. If cash is insufficient after reducing buybacks, the model must flag a funding shortfall for a separate financing decision. |
| Cost of equity: **10.0%** | Judgment | I use a round base-case equity hurdle rate to discount FCFE. It is a scenario input, not an estimated current CAPM result, and it is distinct from the 8.91% WACC in the earlier Apple FCFF model. |
| Terminal growth: **2.5%** | Judgment | I assume mature long-run growth below the five-year revenue growth rate and well below the discount rate. This reduces reliance on unusually strong growth continuing forever. |
| Valuation share count: **14,773.260 million**, at FY2025 year-end | History | The FY2025 balance sheet reports 14,773,260 thousand shares outstanding. Divide by 1,000 to use millions alongside dollar amounts in millions. This is a dated valuation denominator, not a current-market share count or a forecast of shares after buybacks. |
| Securities: **18,763 current + 77,723 non-current**, held flat; other non-current liabilities **41,549**, held flat | Judgment | I keep these balances unchanged to avoid inventing purchases, sales, fair-value movements or a detailed long-term liability forecast. This also means no cash flow from changes in these balances. |
| Current operating liabilities excluding tax: **53,371** opening balance, scaled with sales; income tax payable **13,016**, held flat | Judgment | I separate the tax balance from other current liabilities using Note 6 (66,387 minus 13,016). I hold tax payable flat and assume cash tax equals modeled tax expense rather than repeat the prior exceptional settlement. |
| Deferred tax assets: **20,777**, held flat; other non-current assets excluding DTA: **62,950**, reduced by **3,698** a year | Judgment | I isolate the reported deferred tax assets using Note 6. I allocate the approximate non-PP&E D&A residual to the remaining long-term assets as a simplified roll-forward, without claiming that every asset in the category is amortizable. |
| Stock compensation: **no separate cash-flow addback or share issuance** | Judgment | I retain the compensation expense embedded in historical margins and give no additional cash-flow benefit for stock compensation. This is a conservative cash-equivalent simplification, not a forecast of Apple's actual stock-award accounting; a dilution model would be needed to add it back consistently. |
| Debt classification: current portion **min(10,932, remaining term debt)** at each projected year-end | Judgment | I classify the next modeled repayment as current, consistent with the flat repayment policy. This is not the contractual maturity schedule. |
| Terminal financing: **net term-debt repayment zero after FY2030**, with maturities refinanced | Judgment | I stop extending a fixed debt repayment forever, which would eventually create negative debt. Refinancing preserves the remaining balance rather than claiming it disappears. |
| Terminal non-PP&E reinvestment: **3,698** added to the capital-spending base before terminal growth | Judgment | I replace the assets consumed by the non-PP&E amortization addback in the continuing business rather than value that addback as free cash forever. |
| Valuation bridge: **no separate opening cash or securities add-on**; no separate debt subtraction | Judgment | I follow the course's simplified total-company FCFE valuation. Net other income remains in earnings; I do not value investment income and automatically add the same assets a second time. The absence of a separate excess-asset valuation is a limitation, not a claim these assets have no value. |


### Partner attack and two-sentence answer

**Partner attack, as reported by the student (paraphrased):** Your implied growth rate is questionable; why does the valuation support that growth assumption?

**Student's reported response:** The current valuation shows a strong predicted growth rate.

**Two-sentence answer, edited for precision and to address what would change the assumption:** The current market price can imply strong growth under a given discount rate and margin assumption, but it does not prove that Apple will deliver that growth; my forward base case uses 5% revenue growth, which is different from the growth solved in a reverse DCF. I would change that 5% assumption if subsequent filings showed sustained revenue growth or operating performance that the current base case does not explain, and I would test discount-rate and margin assumptions before treating the price gap as evidence about growth alone.

**My attack on my partner, as reported by the student (paraphrased):** I thought their assumed growth rate was too low relative to the market price. A precise expression of that concern is: under your discount rate and margin assumptions, what growth would reconcile your model to the observed price, and what filing evidence supports using a lower rate?

The partner's numeric growth assumption, ticker and response were not supplied; none is invented. The expanded wording above clarifies the reported exchange and should be reviewed before submission.

## I — opening balance sheet and links

Opening FY2025 assets and liabilities plus equity both equal **359,241**. All balances below come from the [FY2025 10-K, p. 31 and Note 6, p. 40](https://www.sec.gov/Archives/edgar/data/320193/000032019325000079/aapl-20250927.htm), with the stated splits taken from Note 6.

| Opening account | USD millions |
|---|---:|
| cash | 35,934 |
| securities current | 18,763 |
| receivables | 39,777 |
| vendor receivables | 33,180 |
| inventory | 5,718 |
| other current assets | 14,585 |
| securities long | 77,723 |
| ppe | 49,834 |
| deferred tax assets | 20,777 |
| other long assets | 62,950 |
| payables | 69,860 |
| tax payable | 13,016 |
| other current liabilities | 53,371 |
| deferred revenue | 9,055 |
| commercial paper | 7,979 |
| debt current | 12,350 |
| debt long | 78,328 |
| other long liabilities | 41,549 |
| equity | 73,733 |

Receivables, vendor receivables and other current assets follow their FY2025 revenue ratios. Accounts payable, current liabilities excluding tax, and deferred revenue also follow revenue. Their net change is other working-capital investment; inventory is calculated separately. Other long-term liabilities and tax balances stay flat; cash tax therefore equals modeled tax expense. This is a simplified aggregate-account projection, not a complete tax or lease schedule.

Cash is calculated from opening cash plus CFO, CFI and CFF. Equity changes by net income less dividends and buybacks. Commercial paper is unchanged, term debt falls with repayment, PP&E changes with capex and depreciation, and the non-tax other long-term asset balance falls with the separately modeled amortization residual. Cash is never used as a typed balancing plug.

## V — check block and valuation

| Line, USD millions | FY2026E | FY2027E | FY2028E | FY2029E | FY2030E |
|---|---:|---:|---:|---:|---:|
| Revenue | 436,969.1 | 458,817.5 | 481,758.4 | 505,846.3 | 531,138.6 |
| Operating income | 139,773.7 | 146,762.4 | 154,100.5 | 161,805.6 | 169,895.8 |
| Net income | 117,140.3 | 123,010.8 | 129,174.8 | 135,647.0 | 142,442.9 |
| FCFE | 107,142.0 | 113,867.5 | 120,769.4 | 127,882.6 | 135,239.1 |
| Closing cash | 36,944.0 | 44,679.5 | 59,316.9 | 81,067.5 | 110,174.7 |
| Assets − liabilities − equity | 0.0 | 0.0 | 0.0 | 0.0 | 0.0 |
| Cash above floor | Yes | Yes | Yes | Yes | Yes |

No year draws a revolver: there is no modeled facility, and operating cash generation funds investment, scheduled debt repayment and distributions while preserving the floor. All five years have positive FCFE, so the lab's negative-FCFE exception does not affect this valuation.

The refusal test replaces FY2026 cash with its opening 35,934 instead of the computed 36,944.0. The model raises **FY2026E: assets − liabilities − equity gap −1,010.0** and does not value the broken statements. Additional tests verify that excessive buybacks are reduced to preserve the cash floor and an unaffordable dividend blocks valuation.

| Valuation component | Result |
|---|---:|
| PV of five explicit FCFE, $m | 453,561.46 |
| Normalized FY2030 FCFE for terminal calculation, $m | 142,473.14 |
| Terminal value at end of FY2030, $m | 1,947,132.87 |
| PV of terminal value, $m | 1,209,016.32 |
| Equity value, $m | 1,662,577.78 |
| Share of value after FY2030 | 72.72% |
| Historical share denominator, millions | 14,773.260 |
| Value per share | $112.54 |

`FCFE = net income + PP&E depreciation + other D&A − inventory investment − other WC investment − capex − term-debt repayment`

`Terminal value = (FY2030 FCFE + FY2030 repayment − replacement investment for other D&A) × 1.025 / (0.10 − 0.025)`

The terminal normalization assumes refinancing of debt maturities and replaces assets consumed by the non-PP&E amortization addback. Explicit FCFE and terminal value are discounted one through five years to the FY2025 model base. Dividends and buybacks are uses of FCFE, not additional deductions in the valuation. The fixed historical share count is used for the per-share comparison; no post-buyback share forecast is claimed.

**Price comparison, as a question:** The model says **$112.54 per share** and the market closed at **$335.92 on September 24, 2026, 4:00 p.m. EDT**; using the same **14,773.260 million** historical shares for both, what growth, margins or discount rate would explain the gap?

Source: [Yahoo Finance Japan, AAPL quote](https://finance.yahoo.co.jp/quote/AAPL), retrieved September 24, 2026 after the close; the source displays September 25 at 05:00 Japan time and September 24 at 16:00 local U.S. market time. This NASDAQ AAPL quotation is USD. Applying the market price to the same historical denominator gives **$4,962,633.50 million**, which is a like-denominator comparison, not the current reported market capitalization.

The price is current to the cited close; the model is based on FY2025 filings and has not been rolled forward using FY2026 interim results or the current share count. This timing difference, the omitted excess-cash/securities bridge, flat net other expense despite declining debt, simplified tax balances and conservative treatment of stock compensation limit the economic interpretation of the gap. Balanced statements establish internal consistency, not forecasting accuracy.

## Organic growth — learn on your own

Organic growth is expansion from the existing business rather than acquisitions; same-store or comparable growth usually focuses on a defined set of locations operating in both periods. The definitions can differ by company and should be checked before equating them.

Apple's reviewed MD&A provides product/service and geographic sales growth, but no numeric organic or same-store growth measure was found. Reported growth is −2.80%, 2.02% and 6.43% for FY2023–FY2025. Organic growth remains **unresolved as a forecast input**, not zero. The three-year ratio file contains the filing references and comparison.

The lab says the ABG video uses **1.8% organic growth** while reported growth was **4.7%**: an existing-business forecast should not automatically repeat growth contributed by acquisitions or other changes in scope. The numerical 2.9-percentage-point gap alone does not establish an exact acquisition contribution; the video's full bridge was not supplied.

## Reflection — draft talking points

**Label I would defend longest:** I would defend separately modeling R&D as a judgment anchored in history, because Apple reported 34,550 of R&D in FY2025 and omitting it would materially inflate operating income. I can debate the future 8.3% rate, but the expense itself cannot disappear just because the ABG template has no separate row.

**One number that surprised me — suggested point to review:** FY2024's effective tax rate was approximately 24.1%, compared with 14.7% in FY2023 and 15.6% in FY2025; the approximately $10.2 billion one-time net State Aid charge helps explain the jump. This is why I would not mechanically use the latest three-year average as a recurring tax assumption. [FY2024 10-K, Item 7, p. 25](https://www.sec.gov/Archives/edgar/data/320193/000032019324000123/aapl-20240928.htm).

These reflection paragraphs are proposed wording, not a claim about unreported personal reactions or a completed oral reflection.

## Checkout status

The code, five-year statements, balance checks, deliberate refusal, source grid, Yahoo reconciliation, labeled assumptions and price comparison are provided. Personal filing checks and the partner exchange are recorded from the student's replies, with edited explanatory wording identified above. Review the first-person reasons and reflection wording before submitting individually.

GitHub submission links require upload. No upload is claimed for this Lab 10 package; the earlier Lab 09 push was blocked by authentication. Upload the files together into a Lab10 folder and submit the actual GitHub links to this checkout and `apple_proforma.py`.
