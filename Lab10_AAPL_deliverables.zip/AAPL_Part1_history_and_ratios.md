# AAPL — Part 1 history grid and ratios, FY2023–FY2025

Prepared September 24, 2026. All financial amounts are USD millions unless otherwise stated. Each year's history is taken from that year's own 10-K. Balance-sheet items are fiscal year-end balances; PP&E is net of accumulated depreciation. These are historical inputs, not forecast assumptions.

## 1. Three-year history grid

| Item | FY2023 | FY2024 | FY2025 |
|---|---:|---:|---:|
| Revenue | 383,285 [23-IS] | 391,035 [24-IS] | 416,161 [25-IS] |
| Gross profit | 169,148 [23-IS] | 180,683 [24-IS] | 195,201 [25-IS] |
| SG&A | 24,932 [23-IS] | 26,097 [24-IS] | 27,601 [25-IS] |
| Net income | 96,995 [23-IS] | 93,736 [24-IS] | 112,010 [25-IS] |
| Inventory | 6,331 [23-BS] | 7,286 [24-BS] | 5,718 [25-BS] |
| PP&E, net | 43,715 [23-BS] | 45,680 [24-BS] | 49,834 [25-BS] |
| Shareholders' equity | 62,146 [23-BS] | 56,950 [24-BS] | 73,733 [25-BS] |

Apple labels dollar gross profit as “Gross margin” in its income statement. The percentage gross margin is calculated below. SG&A excludes the separately reported R&D expense; it is not total operating expenses.

### Source key — filing and printed page

| Code | Source |
|---|---|
| 23-IS | [FY2023 10-K, p. 28, Consolidated Statements of Operations](https://www.sec.gov/Archives/edgar/data/320193/000032019323000106/aapl-20230930.htm) |
| 23-BS | [FY2023 10-K, p. 30, Consolidated Balance Sheets](https://www.sec.gov/Archives/edgar/data/320193/000032019323000106/aapl-20230930.htm) |
| 23-CF | [FY2023 10-K, p. 32, Consolidated Statements of Cash Flows](https://www.sec.gov/Archives/edgar/data/320193/000032019323000106/aapl-20230930.htm) |
| 23-PPE | [FY2023 10-K, Note 5, Property, Plant and Equipment](https://www.sec.gov/Archives/edgar/data/320193/000032019323000106/aapl-20230930.htm) |
| 24-IS | [FY2024 10-K, p. 29, Consolidated Statements of Operations](https://www.sec.gov/Archives/edgar/data/320193/000032019324000123/aapl-20240928.htm) |
| 24-BS | [FY2024 10-K, p. 31, Consolidated Balance Sheets](https://www.sec.gov/Archives/edgar/data/320193/000032019324000123/aapl-20240928.htm) |
| 24-CF | [FY2024 10-K, p. 33, Consolidated Statements of Cash Flows](https://www.sec.gov/Archives/edgar/data/320193/000032019324000123/aapl-20240928.htm) |
| 24-PPE | [FY2024 10-K, Note 5, Property, Plant and Equipment](https://www.sec.gov/Archives/edgar/data/320193/000032019324000123/aapl-20240928.htm) |
| 25-IS | [FY2025 10-K, p. 29, Consolidated Statements of Operations](https://www.sec.gov/Archives/edgar/data/320193/000032019325000079/aapl-20250927.htm) |
| 25-BS | [FY2025 10-K, p. 31, Consolidated Balance Sheets](https://www.sec.gov/Archives/edgar/data/320193/000032019325000079/aapl-20250927.htm) |
| 25-CF | [FY2025 10-K, p. 33, Consolidated Statements of Cash Flows](https://www.sec.gov/Archives/edgar/data/320193/000032019325000079/aapl-20250927.htm) |
| 25-PPE | [FY2025 10-K, Note 5, p. 39, Property, Plant and Equipment](https://www.sec.gov/Archives/edgar/data/320193/000032019325000079/aapl-20250927.htm) |

### Two checks for the student to perform

The AI opened the filings and confirmed the grid. The student separately confirmed checking FY2023 revenue and FY2024 net income personally.

- [x] FY2023 revenue: **383,285 million**, FY2023 10-K, printed p. 28. Checked personally by the student, as confirmed in this conversation.
- [x] FY2024 net income: **93,736 million**, FY2024 10-K, printed p. 29. Checked personally by the student, as confirmed in this conversation.

No numerical history-grid item remains unresolved.

## 2. Inputs supporting the ratios

| Input | FY2023 | FY2024 | FY2025 |
|---|---:|---:|---:|
| Cost of sales | 214,137 [23-IS] | 210,352 [24-IS] | 220,960 [25-IS] |
| PP&E depreciation expense, approximately | 8,500 [23-PPE] | 8,200 [24-PPE] | 8,000 [25-PPE] |
| Broader depreciation and amortization, for distinction | 11,519 [23-CF] | 11,445 [24-CF] | 11,698 [25-CF] |
| Cash capital spending, positive magnitude | 10,959 [23-CF] | 9,447 [24-CF] | 12,715 [25-CF] |
| Income tax provision | 16,741 [23-IS] | 29,749 [24-IS] | 20,719 [25-IS] |
| Pretax income | 113,736 [23-IS] | 123,485 [24-IS] | 132,729 [25-IS] |
| Prior-year revenue, comparative column | 394,328 [23-IS] | 383,285 [24-IS] | 391,035 [25-IS] |

PP&E depreciation is disclosed rounded to $8.5 billion, $8.2 billion and $8.0 billion. The ratios based on these figures are therefore approximate. Total D&A is not substituted for PP&E depreciation.

## 3. Three-year ratio table

| Measure | Calculation | FY2023 | FY2024 | FY2025 |
|---|---|---:|---:|---:|
| Gross margin | Gross profit / revenue | 44.13% | 46.21% | 46.91% |
| SG&A / gross profit | SG&A / gross profit | 14.74% | 14.44% | 14.14% |
| Inventory days | Closing inventory / cost of sales × 365 | 10.79 | 12.64 | 9.45 |
| Depreciation / PP&E | PP&E depreciation / closing net PP&E | ~19.44% | ~17.95% | ~16.05% |
| Effective tax rate | Income tax provision / pretax income | 14.72% | 24.09% | 15.61% |
| Reported revenue growth, calculated | Current revenue / prior revenue − 1 | −2.80% | 2.02% | 6.43% |

Sources for every numerator and denominator are in the history and supporting-input grids above. Ratios use full input precision before rounding for display.

The inventory-days and depreciation ratios follow the historical calibration convention in the supplied ABG lab: closing inventory and closing net PP&E. They do not use average balances. The engine may then apply the calibrated depreciation ratio to opening PP&E in the projected year. A constant 365-day factor is used to match the course instruction even though FY2023 contained 53 weeks.

Example FY2025 arithmetic:

- Gross margin: 195,201 / 416,161 = 46.91%.
- SG&A / gross profit: 27,601 / 195,201 = 14.14%.
- Inventory days: 5,718 / (416,161 − 195,201) × 365 = 9.45 days.
- Depreciation / PP&E: approximately 8,000 / 49,834 = 16.05%.
- Effective tax rate: 20,719 / 132,729 = 15.61%.
- Revenue growth: 416,161 / 391,035 − 1 = 6.43%.

## 4. Capital spending: 10-K beside Yahoo Finance

Yahoo Finance's annual cash-flow table labels the field **Capital Expenditure** and displays **USD thousands**. The 10-K cash-flow line is payments to acquire PP&E and is reported in **USD millions**. Both present cash outflows with negative signs; the forecasting input above uses the positive spending magnitude.

| Fiscal year | 10-K PP&E cash outflow, $m | Yahoo Capital Expenditure, $000 | Yahoo converted to $m | Difference, $m |
|---|---:|---:|---:|---:|
| 2023 | −10,959 [23-CF] | −10,959,000 [Yahoo] | −10,959 | 0 |
| 2024 | −9,447 [24-CF] | −9,447,000 [Yahoo] | −9,447 | 0 |
| 2025 | −12,715 [25-CF] | −12,715,000 [Yahoo] | −12,715 | 0 |

[Yahoo: AAPL annual cash-flow table](https://ca.finance.yahoo.com/quote/AAPL/cash-flow/), accessed September 24, 2026. The Canadian Yahoo page reports USD, not CAD. It labels annual columns September 30; match these annual columns to the fiscal years, whose actual year-end dates are September 30, 2023, September 28, 2024 and September 27, 2025. Do not use the separate TTM column. All three capex comparisons reconcile after dividing Yahoo's thousands by 1,000. The main U.S. page failed to load, but Yahoo's Canadian page supplied the field.

## 5. Reported growth beside organic / same-store growth

| Fiscal year | Calculated reported revenue growth | Rounded growth in MD&A | Organic / same-store growth disclosure | MD&A source |
|---|---:|---:|---|---|
| 2023 | −2.80% | −3% | No numeric measure found; unresolved as a model input | [FY2023 10-K, Item 7, pp. 20–22](https://www.sec.gov/Archives/edgar/data/320193/000032019323000106/aapl-20230930.htm) |
| 2024 | 2.02% | 2% | No numeric measure found; unresolved as a model input | [FY2024 10-K, Item 7, pp. 21–23](https://www.sec.gov/Archives/edgar/data/320193/000032019324000123/aapl-20240928.htm) |
| 2025 | 6.43% | 6% | No numeric measure found; unresolved as a model input | [FY2025 10-K, Item 7, pp. 21–23](https://www.sec.gov/Archives/edgar/data/320193/000032019325000079/aapl-20250927.htm) |

Apple discusses net sales by geographic segment and product/service category, plus currency effects, rather than a numeric growth rate for stores already owned. Searches for “organic” and “same-store” in each filing found no matches, and the MD&A sales discussion did not provide that metric. Reported revenue growth must not be relabeled organic growth or same-store sales growth. The absence of a disclosed figure does not mean zero growth.

FY2023 had 53 weeks and FY2024 had 52, which affects comparability; no week-adjusted organic growth is calculated here. The FY2024 MD&A also identifies a one-time net tax charge of approximately $10.2 billion related to the State Aid Decision. Therefore the historical 24.09% tax rate should not automatically become a recurring forecast tax rate. [FY2024 10-K, Item 7, pp. 21 and 25](https://www.sec.gov/Archives/edgar/data/320193/000032019324000123/aapl-20240928.htm).

## Completion status

- History values and ratios: confirmed from the three filings and calculated.
- Yahoo capex comparison: confirmed; differences are zero after unit conversion.
- Organic / same-store growth: no numeric disclosure found; unresolved as a forecasting input.
- Exact unrounded PP&E depreciation: not disclosed in the cited note; use the explicitly approximate historical ratio.
- Student's two independent filing checks: complete, as confirmed by the student (FY2023 revenue and FY2024 net income).
